/* ============================================================================
   Tizon Books · הנהלת חשבונות לכל העסקים
   A standalone app. It touches nothing of the store: not its code, not its
   Firebase, not its rules.

   Two ways to keep the data:
     · on this computer (the default) — works the moment it is opened, with
       a backup file that can be downloaded and restored at any time;
     · in its own Firebase project — pasted in under "גיבוי וענן", and from
       then on the data is in the cloud, behind a login, on every device.

   Every business is a "book":
     books/{book}                   name, dealer type, VAT, tax id, owners
     books/{book}/incomes/{id}      income
     books/{book}/expenses/{id}     expenses and their deductible VAT
     books/{book}/suppliers/{id}    who is paid
     books/{book}/banktx/{id}       bank statement lines and their matches

   Linking a book to the store comes later, as a step of its own.
   ==========================================================================*/

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import { initializeApp } from 'firebase/app';
import {
  initializeFirestore, collection, doc, getDocs, setDoc, deleteDoc, query, where
} from 'firebase/firestore';
import {
  getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, onAuthStateChanged, signOut, sendPasswordResetEmail
} from 'firebase/auth';

const VERSION = '1.0.0';
const BUILD_DATE = '29.09.26';
const OLD_ERP_URL = 'https://tizon-event-default-rtdb.firebaseio.com/tizon_live_data.json';
const CLOUD_KEY = 'tzbooks_cloud';
const LOCAL_KEY = 'tzbooks_data';
const BACKUP_KEY = 'tzbooks_lastbackup';

/* ------------------------------------------------------------- storage */
const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } };
const lsSet = (k, v) => { localStorage.setItem(k, JSON.stringify(v)); };

/* The cloud, if a Firebase project was connected on this device. */
let cloud = null;
const cloudCfg = lsGet(CLOUD_KEY, null);
if (cloudCfg?.apiKey && cloudCfg?.projectId) {
  try {
    const app = initializeApp(cloudCfg);
    cloud = { db: initializeFirestore(app, { experimentalAutoDetectLongPolling: true }), auth: getAuth(app), cfg: cloudCfg };
  } catch (e) { console.warn('cloud config', e); }
}
const MODE = cloud ? 'cloud' : 'local';
const hasLocalData = () => Object.keys(lsGet(LOCAL_KEY, {})).length > 0;

/* One small interface over both, addressed by path ("books", "books/x/expenses"). */
const kidsOf = (o, path) => Object.keys(o).filter(k => k.startsWith(path + '/') && !k.slice(path.length + 1).includes('/'));
const local = {
  async list(path) { const o = lsGet(LOCAL_KEY, {}); return kidsOf(o, path).map(k => ({ ...o[k], id: k.split('/').pop() })); },
  async put(path, id, data) {
    const o = lsGet(LOCAL_KEY, {}); o[path + '/' + id] = data;
    try { lsSet(LOCAL_KEY, o); } catch { throw new Error('האחסון בדפדפן מלא. עבור לענן או מחק נתונים ישנים.'); }
  },
  async del(path, id) { const o = lsGet(LOCAL_KEY, {}); delete o[path + '/' + id]; lsSet(LOCAL_KEY, o); },
  async books() { return this.list('books'); },
};
const remote = {
  async list(path) { const s = await getDocs(collection(cloud.db, ...path.split('/'))); return s.docs.map(d => ({ ...d.data(), id: d.id })); },
  put: (path, id, data) => setDoc(doc(cloud.db, ...path.split('/'), id), data),
  del: (path, id) => deleteDoc(doc(cloud.db, ...path.split('/'), id)),
  async books(email) {
    const s = await getDocs(query(collection(cloud.db, 'books'), where('owners', 'array-contains', email.toLowerCase())));
    return s.docs.map(d => ({ ...d.data(), id: d.id }));
  },
};
const DB = cloud ? remote : local;

const COLS = ['incomes', 'expenses', 'suppliers', 'banktx'];
const bookCol = (bookId, name) => ({
  list: () => DB.list(`books/${bookId}/${name}`),
  put: (id, data) => DB.put(`books/${bookId}/${name}`, id, data),
  del: (id) => DB.del(`books/${bookId}/${name}`, id),
});
const listBooks = (email) => DB.books(email);
const putBook = (b) => DB.put('books', b.id, b);
const delBook = (id) => DB.del('books', id);

/* Everything, as one file: every book with its records. Same shape from
   either storage, and restorable into either. */
async function exportAll(email, src = DB) {
  const books = await src.books(email);
  const out = { app: 'tizon-books', version: VERSION, exportedAt: new Date().toISOString(), books: [] };
  for (const b of books) {
    const data = {};
    for (const c of COLS) data[c] = await src.list(`books/${b.id}/${c}`);
    out.books.push({ ...b, data });
  }
  return out;
}
async function importAll(file, me) {
  if (!file || file.app !== 'tizon-books' || !Array.isArray(file.books)) throw new Error('זה לא קובץ גיבוי של המערכת');
  let n = 0;
  for (const bk of file.books) {
    const { data = {}, ...b } = bk;
    const owners = [...new Set([...(b.owners || []), ...(me ? [me.toLowerCase()] : [])])];
    await putBook(clean({ ...b, owners }));
    for (const c of COLS) for (const r of (data[c] || [])) { const { id, ...rest } = r; await bookCol(b.id, c).put(id, clean(rest)); n++; }
  }
  return { books: file.books.length, records: n };
}
function saveJSON(name, obj) {
  const blob = new Blob([JSON.stringify(obj, null, 1)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

/* The config Firebase shows under Project settings, pasted as it is — the
   whole <script> block, the object, or JSON. */
function parseFirebaseConfig(text) {
  const out = {};
  ['apiKey', 'authDomain', 'projectId', 'storageBucket', 'messagingSenderId', 'appId'].forEach(k => {
    const m = String(text).match(new RegExp(`["']?${k}["']?\\s*:\\s*["']([^"']+)["']`));
    if (m) out[k] = m[1];
  });
  return out.apiKey && out.projectId ? out : null;
}

const KINDS = { store: 'חנות', clinic: 'קליניקה', platform: 'פלטפורמה', other: 'אחר' };
const DEALERS = { exempt: 'עוסק פטור', licensed: 'עוסק מורשה', company: 'חברה בע״מ' };
const INC_CATS = ['טיפולים', 'ייעוץ', 'סדנאות וקורסים', 'מנויים ורישיונות', 'מוצרים', 'הרצאות', 'אחר'];
const EXP_CATS = ['מלאי וחומרי גלם', 'שכירות', 'שיווק ופרסום', 'ציוד', 'שכר', 'ביטוח', 'רכב ונסיעות',
                  'תוכנה ומנויים', 'משלוחים', 'עמלות סליקה', 'הנהלת חשבונות', 'אחר'];
const PAY_METHODS = ['העברה בנקאית', 'כרטיס אשראי', 'ביט', 'פייבוקס', 'מזומן', 'צ׳ק', 'הוראת קבע'];
const BOOK_COLORS = ['#1f5a3d', '#b8893b', '#2b4bb8', '#8a2450', '#35318a', '#7a3f14'];

/* ------------------------------------------------------------------ helpers */
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
/* The minus sign stays in front of the shekel sign inside Hebrew text. */
const fmt = (n) => (r2(n) < 0 ? '\u200E-' : '') + '₪' + Math.abs(r2(n)).toLocaleString('en-US', { maximumFractionDigits: 2 });
const pad = (n) => String(n).padStart(2, '0');
const thisMonth = () => new Date().toISOString().slice(0, 7);
const todayIso = () => new Date().toISOString().slice(0, 10);
const clean = (o) => JSON.parse(JSON.stringify(o));
const uid = (p = 'id') => p + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const withTimeout = (p, ms = 15000) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms))]);

function d10(v) {
  if (!v) return '';
  const s = String(v).trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
  const m = s.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{2,4})/);
  if (m) return `${m[3].length === 2 ? '20' + m[3] : m[3]}-${pad(m[2])}-${pad(m[1])}`;
  const t = Date.parse(s);
  return isNaN(t) ? '' : new Date(t).toISOString().slice(0, 10);
}
const heDate = (d) => d ? d.split('-').reverse().join('/') : '—';
const monthName = (ym) => {
  const [y, m] = ym.split('-').map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString('he-IL', { month: 'short', year: '2-digit' });
};
const addMonths = (ym, k) => {
  const [y, m] = ym.split('-').map(Number);
  const d = new Date(y, m - 1 + k, 1);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
};
/* Israeli bi-monthly VAT periods start on odd months: Jan–Feb, Mar–Apr … */
const biStart = (ym) => { const [y, m] = ym.split('-').map(Number); return `${y}-${pad(m % 2 ? m : m - 1)}`; };
const inMonths = (date, from, to) => { const m = (date || '').slice(0, 7); return m >= from && m <= to; };
const vatOf = (gross, rate) => rate > 0 ? r2(gross * rate / (100 + rate)) : 0;
const num = (s) => {
  let t = String(s ?? '').replace(/[₪,\s]/g, '');
  let neg = false;
  if (/^\(.*\)$/.test(t)) { neg = true; t = t.slice(1, -1); }
  if (/-$/.test(t)) { neg = true; t = t.slice(0, -1); }
  const n = parseFloat(t);
  return isNaN(n) ? NaN : (neg ? -Math.abs(n) : n);
};
const rateOf = (book) => book?.dealerType === 'exempt' ? 0 : (Number(book?.vatRate) || 0);
const paidOnPage = (o) => o?.paidVia === 'icount' || o?.payProvider === 'icountpay';
const isPaidOrder = (o) => o && o.payStatus === 'paid' && o.status !== 'cancelled';

function downloadCSV(name, rows) {
  const body = rows.map(r => r.map(c => {
    const s = String(c ?? '');
    return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }).join(',')).join('\n');
  const blob = new Blob(['﻿' + body], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

function splitLine(line, sep) {
  const out = []; let cur = ''; let q = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') { if (q && line[i + 1] === '"') { cur += '"'; i++; } else q = !q; }
    else if (ch === sep && !q) { out.push(cur.trim()); cur = ''; }
    else cur += ch;
  }
  out.push(cur.trim());
  return out;
}

/* A bank statement CSV into { date, desc, amount }. Israeli banks split money
   out and in (חובה / זכות); others use one signed column. */
function parseBankCSV(text) {
  const lines = text.replace(/\r/g, '').split('\n').filter(l => l.trim());
  if (!lines.length) return [];
  const sep = [',', ';', '\t'].map(s => [s, lines[0].split(s).length]).sort((a, b) => b[1] - a[1])[0][0];
  const rows = lines.map(l => splitLine(l, sep));
  const hi = rows.findIndex(r => r.some(c => /תאריך|date/i.test(c)));
  const head = hi >= 0 ? rows[hi] : null;
  const col = (re) => head ? head.findIndex(c => re.test(c)) : -1;
  const cDate = col(/תאריך|date/i), cDesc = col(/תיאור|פרטים|הפעולה|description|details/i);
  const cDebit = col(/חובה|debit|חיוב/i), cCredit = col(/זכות|credit|זיכוי/i);
  const cAmt = col(/סכום|amount/i);
  const out = [];
  rows.slice(hi >= 0 ? hi + 1 : 0).forEach(r => {
    const date = d10(cDate >= 0 ? r[cDate] : r.find(c => d10(c) && /\d/.test(c)));
    if (!date) return;
    let amount = NaN;
    if (cDebit >= 0 || cCredit >= 0) {
      const dr = cDebit >= 0 ? num(r[cDebit]) : NaN, cr = cCredit >= 0 ? num(r[cCredit]) : NaN;
      amount = (isNaN(cr) ? 0 : Math.abs(cr)) - (isNaN(dr) ? 0 : Math.abs(dr));
      if (isNaN(dr) && isNaN(cr)) amount = NaN;
    } else if (cAmt >= 0) amount = num(r[cAmt]);
    else amount = r.map(num).find((n, i) => !isNaN(n) && !d10(r[i]));
    if (isNaN(amount) || amount === 0) return;
    const desc = cDesc >= 0 ? r[cDesc]
      : r.filter(c => isNaN(num(c)) && !d10(c)).sort((a, b) => b.length - a.length)[0] || '';
    out.push({ date, desc: String(desc).slice(0, 120), amount: r2(amount) });
  });
  return out;
}

/* ------------------------------------------------------------ the ledger */
/* One list of income and one of expenses for a book, whatever their source. */
function buildLedger(book, data) {
  const rate = rateOf(book);
  const docByOrder = Object.fromEntries((data?.docs || []).map(d => [d.orderId, d]));
  const fromShop = (data?.orders || []).filter(isPaidOrder).map(o => {
    const gross = r2(o.total);
    const d = docByOrder[o.id];
    return {
      id: 'o:' + o.id, src: 'shop', date: d10(o.paidAt) || d10(o.createdIso) || d10(o.createdAt),
      desc: `הזמנה ${o.code || o.id}${o.customerName ? ' · ' + o.customerName : ''}`,
      cat: 'מכירות בחנות', pay: o.payment || '', gross,
      vat: rate === 0 ? 0 : (d && d.vat != null ? r2(d.vat) : vatOf(gross, rate)),
      docNo: o.invoiceNo || (paidOnPage(o) ? 'iCount' : ''),
    };
  });
  const manual = (data?.incomes || []).map(i => ({
    ...i, src: i.src || 'manual', gross: r2(i.gross),
    vat: rate === 0 || i.noVat ? 0 : (i.vat != null ? r2(i.vat) : vatOf(i.gross, rate)),
  }));
  const income = [...fromShop, ...manual].sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  const outgo = (data?.expenses || []).map(e => ({ ...e, gross: r2(e.gross), vat: rate === 0 ? 0 : r2(e.vat) }))
    .sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  return { income, outgo, rate };
}
function totals(ledger, from, to) {
  const inc = ledger.income.filter(i => inMonths(i.date, from, to));
  const exp = ledger.outgo.filter(e => inMonths(e.date, from, to));
  const incGross = inc.reduce((a, i) => a + i.gross, 0), incVat = inc.reduce((a, i) => a + i.vat, 0);
  const expGross = exp.reduce((a, e) => a + e.gross, 0), expVat = exp.reduce((a, e) => a + e.vat, 0);
  return { inc, exp, incGross, incVat, incNet: incGross - incVat, expGross, expVat, expNet: expGross - expVat,
           profit: (incGross - incVat) - (expGross - expVat), vatDue: incVat - expVat };
}
function alertsOf(data, ledger) {
  return {
    unmatched: (data?.banktx || []).filter(b => !b.matchId && !b.ignored).length,
    noDocOrders: (data?.orders || []).filter(o => isPaidOrder(o) && !o.invoiceNo && !paidOnPage(o)).length,
    noDocExp: ledger.outgo.filter(e => !e.docNo && !e.hasDoc).length,
    review: [...(data?.incomes || []), ...(data?.expenses || [])].filter(x => x.review).length,
  };
}


async function loadBook(book) {
  const res = await Promise.all(COLS.map(c => withTimeout(bookCol(book.id, c).list()).catch(() => null)));
  const out = { errors: [], orders: [], docs: [], storeErr: '' };
  COLS.forEach((c, i) => { out[c] = res[i] || []; if (!res[i]) out.errors.push(c); });
  return out;
}

/* ================================================================== styles */
const CSS = `
:root{--bg:#f6f2ea;--card:#fff;--ink:#1d2a23;--muted:#5b6b62;--line:#e6e0d4;--green:#1f5a3d;--green2:#2f7d5b;
  --gold:#b8893b;--warn:#a2680f;--bad:#b3261e;--soft:#f1ece2}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font-family:'Assistant','Segoe UI',system-ui,sans-serif;font-size:15px}
button,input,select,textarea{font-family:inherit;font-size:14px}
input,select,textarea{border:1.5px solid var(--line);border-radius:10px;padding:9px 11px;background:#fff;color:var(--ink);width:100%;outline:none}
input:focus,select:focus{border-color:var(--gold)}
.shell{display:flex;min-height:100vh}
.side{width:250px;background:#16271e;color:#e9e4d8;padding:18px 12px;flex-shrink:0;display:flex;flex-direction:column;gap:4px}
.brand{font-family:'Frank Ruhl Libre',serif;font-size:22px;font-weight:700;color:#e8c98a;padding:4px 10px 14px}
.brand small{display:block;font-family:inherit;font-size:12px;color:#a9b3aa;font-weight:400;margin-top:2px}
.side .sec{font-size:11px;letter-spacing:.08em;color:#8fa093;padding:12px 10px 4px}
.side button.bk{display:flex;align-items:center;gap:10px;width:100%;text-align:right;background:none;border:0;color:inherit;
  padding:10px;border-radius:10px;cursor:pointer;font-size:14px}
.side button.bk:hover{background:rgba(255,255,255,.06)}
.side button.bk.on{background:rgba(232,201,138,.14);color:#fff;font-weight:700}
.dot{width:10px;height:10px;border-radius:50%;flex-shrink:0}
.side .foot{margin-top:auto;font-size:12px;color:#a9b3aa;padding:10px;line-height:1.7}
.side .foot button{background:none;border:0;color:#e8c98a;cursor:pointer;padding:0;text-decoration:underline}
.main{flex:1;padding:24px 28px;min-width:0}
.mg-h{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:18px;padding:20px 22px;border-radius:20px;color:#fff;
  background:linear-gradient(135deg,var(--h1,#1f5a3d),var(--h2,#2f7d5b));box-shadow:0 12px 30px rgba(20,40,30,.15)}
.mg-h > div:first-child{flex:1}
.mg-h h2{margin:0;font-family:'Frank Ruhl Libre',serif;font-size:26px}
.mg-h .sub{opacity:.9;font-size:14px;margin-top:4px}
.mg-h .mg-btn{background:#fff;color:var(--green)}
.mg-h .mg-btn.ghost{background:rgba(255,255,255,.15);color:#fff;border:1.5px solid rgba(255,255,255,.4)}
.mg-tabs{display:flex;gap:6px;flex-wrap:wrap}
.mg-tab{background:#fff;border:1.5px solid var(--line);border-radius:999px;padding:7px 15px;cursor:pointer;font-weight:600;color:var(--muted)}
.mg-tab.on{background:var(--green);border-color:var(--green);color:#fff}
.mg-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px}
.mg-stat{background:var(--card);border:1px solid var(--line);border-top:4px solid var(--green2);border-radius:16px;padding:16px 18px}
.mg-stat:nth-child(4n+2){border-top-color:#2b4bb8}.mg-stat:nth-child(4n+3){border-top-color:#d9822b}.mg-stat:nth-child(4n+4){border-top-color:var(--gold)}
.mg-stat .lb{font-size:13px;font-weight:700;color:var(--muted)}
.mg-stat .vl{font-size:26px;font-weight:800;margin:6px 0 2px}
.mg-stat .dl{font-size:12px;color:var(--muted)}
.mg-card{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:18px 20px}
.mg-card h3{font-size:16px}
.mg-note{background:var(--soft);border-radius:12px;padding:11px 14px;border-inline-start:4px solid var(--green2);font-size:14px;line-height:1.6}
.mg-note.warn{background:#fbf3e4;border-inline-start-color:#d9822b}
.mg-note.bad{background:#fbeceb;border-inline-start-color:var(--bad)}
.mg-empty{border:2px dashed var(--line);border-radius:14px;padding:18px;text-align:center;color:var(--muted);background:#fff}
.mg-tblwrap{overflow-x:auto;background:#fff;border:1px solid var(--line);border-radius:16px}
.mg-tbl{width:100%;border-collapse:collapse}
.mg-tbl th{background:var(--soft);text-align:right;padding:10px 12px;font-size:13px;white-space:nowrap}
.mg-tbl td{padding:10px 12px;border-top:1px solid #f0ebe0;font-size:14px;vertical-align:middle}
.mg-tbl tr:hover td{background:#fbf9f4}
.mg-tbl tfoot td{font-weight:800;background:var(--soft)}
.mg-btn{display:inline-flex;align-items:center;gap:6px;background:var(--green);color:#fff;border:0;border-radius:11px;padding:9px 15px;
  cursor:pointer;font-weight:700;white-space:nowrap}
.mg-btn:disabled{opacity:.45;cursor:not-allowed}
.mg-btn.ghost{background:#fff;color:var(--green);border:1.5px solid var(--line)}
.mg-btn.sm{padding:5px 10px;font-size:13px;border-radius:9px}
.mg-btn.danger{background:var(--bad)}
.mg-chip{display:inline-block;padding:2px 9px;border-radius:999px;font-size:12px;font-weight:700;background:var(--soft);color:var(--muted)}
.mg-chip.ok{background:#e3f1e8;color:#1f5a3d}.mg-chip.warn{background:#fbecd2;color:#8a5a0c}.mg-chip.bad{background:#fbe3e1;color:var(--bad)}
.mg-fld{display:flex;flex-direction:column;gap:4px;min-width:150px}
.mg-fld label{font-size:12px;font-weight:700;color:var(--muted)}
.mg-linkish{background:none;border:0;color:var(--green2);text-decoration:underline;cursor:pointer;padding:0;font-weight:700}
.mg-mod{position:fixed;inset:0;background:rgba(20,30,25,.55);display:flex;align-items:center;justify-content:center;padding:16px;z-index:50}
.mg-mod-in{background:#fff;border-radius:20px;width:100%;max-width:560px;max-height:90vh;display:flex;flex-direction:column}
.mg-mod-h{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--line)}
.mg-mod-h h3{margin:0}
.mg-mod-b{padding:18px 20px;overflow-y:auto}
.mg-mod-f{display:flex;gap:8px;padding:14px 20px;border-top:1px solid var(--line)}
.sf-x{background:none;border:0;font-size:22px;cursor:pointer;color:var(--muted)}
.mlab{font-size:11px;color:var(--muted);white-space:nowrap;overflow:hidden;max-width:100%}
@media (max-width:600px){.mlab{font-size:9px}}
.flash{position:fixed;bottom:20px;left:20px;background:#16271e;color:#fff;padding:12px 18px;border-radius:12px;z-index:60;
  box-shadow:0 10px 30px rgba(0,0,0,.25);max-width:380px}
.login{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:16px;
  background:radial-gradient(circle at 20% 10%,#2b4a38,#16271e 60%)}
.login .card{background:#fff;border-radius:22px;padding:30px;width:100%;max-width:380px;display:flex;flex-direction:column;gap:12px}
.login h1{margin:0;font-family:'Frank Ruhl Libre',serif;color:var(--green)}
@media (max-width:820px){
  .shell{flex-direction:column}
  .side{width:auto;flex-direction:row;flex-wrap:wrap;align-items:center;padding:10px}
  .side .sec,.side .foot small{display:none}
  .brand{padding:4px 8px;font-size:18px}.brand small{display:none}
  .side button.bk{width:auto;padding:7px 10px}
  .side .foot{margin:0;padding:4px 8px}
  .main{padding:14px}
}
`;

/* ===================================================================== ui */
function Field({ label, children }) { return <div className="mg-fld"><label>{label}</label>{children}</div>; }
function Box({ title, onClose, children, footer, wide }) {
  return (
    <div className="mg-mod" onClick={onClose}>
      <div className="mg-mod-in" style={wide ? { maxWidth: 780 } : undefined} onClick={e => e.stopPropagation()}>
        <div className="mg-mod-h"><h3>{title}</h3><button className="sf-x" onClick={onClose} aria-label="סגור">×</button></div>
        <div className="mg-mod-b">{children}</div>
        {footer && <div className="mg-mod-f">{footer}</div>}
      </div>
    </div>
  );
}
const grid = { display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(180px,1fr))', gap: 12 };
const row = { display: 'flex', gap: 8, alignItems: 'flex-end', flexWrap: 'wrap' };

/* ================================================================== login */
function Login() {
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [signup, setSignup] = useState(false);
  const go = async (e) => {
    e.preventDefault(); setBusy(true); setErr('');
    try {
      if (signup) await createUserWithEmailAndPassword(cloud.auth, email.trim(), pw);
      else await signInWithEmailAndPassword(cloud.auth, email.trim(), pw);
    } catch (x) {
      const c = String(x?.code || '');
      setErr(c.includes('email-already') ? 'המשתמש כבר קיים. היכנס עם הסיסמה שלו.'
        : c.includes('weak-password') ? 'סיסמה חלשה מדי. לפחות 6 תווים.'
        : c.includes('operation-not-allowed') || c.includes('configuration-not-found') ? 'בפרויקט ה-Firebase לא הופעלה כניסה באימייל וסיסמה (Authentication ← Sign-in method).'
        : c.includes('invalid') || c.includes('wrong') || c.includes('not-found') ? 'אימייל או סיסמה שגויים'
        : c.includes('too-many') ? 'יותר מדי ניסיונות. נסה שוב בעוד כמה דקות.' : 'הכניסה נכשלה: ' + c);
    }
    setBusy(false);
  };
  return (
    <form className="login" onSubmit={go}>
      <div className="card">
        <h1>Tizon Books</h1>
        <div style={{ color: 'var(--muted)', fontSize: 14 }}>{signup ? 'יצירת משתמש בפרויקט' : 'כניסה'} · <span dir="ltr">{cloud.cfg.projectId}</span></div>
        <Field label="אימייל"><input type="email" dir="ltr" value={email} onChange={e => setEmail(e.target.value)} autoComplete="username" /></Field>
        <Field label="סיסמה"><input type="password" dir="ltr" value={pw} onChange={e => setPw(e.target.value)} autoComplete={signup ? 'new-password' : 'current-password'} /></Field>
        {err && <div className="mg-note bad">{err}</div>}
        <button className="mg-btn" disabled={busy || !email || !pw} style={{ justifyContent: 'center' }}>{busy ? '…' : signup ? 'צור משתמש והיכנס' : 'כניסה'}</button>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14 }}>
          <button type="button" className="mg-linkish" onClick={() => { setSignup(!signup); setErr(''); }}>{signup ? 'יש לי משתמש' : 'משתמש חדש'}</button>
          <button type="button" className="mg-linkish" disabled={!email}
                  onClick={async () => { try { await sendPasswordResetEmail(cloud.auth, email.trim()); setErr('נשלח מייל לאיפוס הסיסמה'); } catch { setErr('לא הצלחתי לשלוח מייל איפוס'); } }}>שכחתי סיסמה</button>
        </div>
        <button type="button" className="mg-linkish" style={{ fontSize: 12, color: 'var(--muted)' }}
                onClick={() => { if (window.confirm('לנתק את הענן ולחזור לשמירה במחשב הזה?')) { localStorage.removeItem(CLOUD_KEY); location.reload(); } }}>
          חזרה לשמירה במחשב הזה</button>
      </div>
    </form>
  );
}

/* ==================================================================== app */
const LOCAL_USER = { email: 'local' };
function App() {
  const [user, setUser] = useState(cloud ? undefined : LOCAL_USER);
  const [books, setBooks] = useState(null);
  const [cur, setCur] = useState('all');
  const [datas, setDatas] = useState({});
  const [loading, setLoading] = useState({});
  const [msg, setMsg] = useState('');
  const [bookForm, setBookForm] = useState(null);
  const [booksErr, setBooksErr] = useState('');
  const flashT = useRef(null);
  const flash = (m) => { setMsg(m); clearTimeout(flashT.current); flashT.current = setTimeout(() => setMsg(''), 4200); };

  useEffect(() => {
    if (!cloud) return;
    return onAuthStateChanged(cloud.auth, u => { setUser(u || null); if (!u) { setBooks(null); setDatas({}); } });
  }, []);

  const sortBooks = (b) => [...b].sort((x, y) => (x.order ?? 99) - (y.order ?? 99) || (x.name || '').localeCompare(y.name || '', 'he'));
  const refreshBooks = async () => {
    try {
      const b = sortBooks(await withTimeout(listBooks(user.email)));
      setBooks(b); setBooksErr('');
      if (!['all', 'settings'].includes(cur) && !b.some(x => x.id === cur)) setCur('all');
    } catch (e) {
      setBooks([]);
      setBooksErr(String(e?.code || e?.message || '').includes('permission')
        ? 'אין הרשאה לקרוא את העסקים. צריך לפרסם בפרויקט ה-Firebase את קובץ החוקים שמגיע עם המערכת.'
        : 'לא הצלחתי לטעון את העסקים. בדוק את החיבור.');
    }
  };
  useEffect(() => { if (user) refreshBooks(); }, [user]);

  const ensure = async (book, force) => {
    if (!force && (datas[book.id] || loading[book.id])) return;
    setLoading(l => ({ ...l, [book.id]: true }));
    const d = await loadBook(book);
    setDatas(x => ({ ...x, [book.id]: d }));
    setLoading(l => ({ ...l, [book.id]: false }));
  };
  useEffect(() => {
    if (!books) return;
    if (cur === 'all') books.forEach(b => ensure(b));
    else { const b = books.find(x => x.id === cur); if (b) ensure(b); }
  }, [cur, books]);

  const patch = (bookId) => (name, fn) =>
    setDatas(d => ({ ...d, [bookId]: { ...d[bookId], [name]: fn(d[bookId]?.[name] || []) } }));

  const saveBook = async (b) => {
    const owners = cloud
      ? [...new Set([user.email.toLowerCase(), ...(b.owners || []).map(x => String(x).trim().toLowerCase()).filter(x => x.includes('@'))])]
      : (b.owners || []);
    const rec = clean({ ...b, owners, name: b.name.trim(), updatedAt: new Date().toISOString() });
    try { await withTimeout(putBook(rec)); }
    catch (e) { flash('שמירת העסק נכשלה · ' + (e?.code || e?.message || '')); return false; }
    const was = books.find(x => x.id === rec.id);
    setBooks(bs => sortBooks([...bs.filter(x => x.id !== rec.id), rec]));
    if (!was) setDatas(x => ({ ...x, [rec.id]: { errors: [], orders: [], docs: [], storeErr: '', incomes: [], expenses: [], suppliers: [], banktx: [] } }));
    flash('העסק נשמר');
    return true;
  };

  const deleteBook = async (b) => {
    if (!window.confirm(`למחוק את "${b.name}" עם כל ההכנסות, ההוצאות, הספקים ושורות הבנק שלו? אי אפשר לשחזר.`)) return;
    if (window.prompt('כדי לאשר, הקלד את שם העסק:') !== b.name) { flash('המחיקה בוטלה'); return; }
    try {
      for (const c of COLS) {
        const list = await bookCol(b.id, c).list();
        for (const r of list) await bookCol(b.id, c).del(r.id);
      }
      await delBook(b.id);
      setBooks(bs => bs.filter(x => x.id !== b.id)); setCur('all'); flash('העסק נמחק');
    } catch (e) { flash('המחיקה נכשלה · ' + (e?.code || '')); }
  };

  if (user === undefined) return <div className="login"><div style={{ color: '#e8c98a' }}>טוען…</div></div>;
  if (!user) return <Login />;

  const book = books?.find(b => b.id === cur);
  const lastBackup = lsGet(BACKUP_KEY, null);
  const stale = !cloud && books?.length > 0 && (!lastBackup || Date.now() - Date.parse(lastBackup) > 7 * 86400000);

  return (
    <div className="shell">
      <aside className="side">
        <div className="brand">Tizon Books<small>הנהלת חשבונות לכל העסקים</small></div>
        <button className={'bk' + (cur === 'all' ? ' on' : '')} onClick={() => setCur('all')}>
          <span className="dot" style={{ background: '#e8c98a' }} />כל העסקים</button>
        <div className="sec">העסקים</div>
        {(books || []).map(b => (
          <button key={b.id} className={'bk' + (cur === b.id ? ' on' : '')} onClick={() => setCur(b.id)}>
            <span className="dot" style={{ background: b.color || '#2f7d5b' }} />{b.name}
          </button>
        ))}
        <button className="bk" onClick={() => setBookForm({})} style={{ color: '#e8c98a' }}>＋ עסק חדש</button>
        <button className={'bk' + (cur === 'settings' ? ' on' : '')} onClick={() => setCur('settings')}>
          <span className="dot" style={{ background: cloud ? '#4f9d6f' : '#d9822b' }} />גיבוי וענן</button>
        <div className="foot">
          <small>{cloud ? user.email : 'נשמר במחשב הזה'}</small><br />
          <button onClick={() => { setDatas({}); refreshBooks(); }}>רענון</button>
          {cloud && <> · <button onClick={() => signOut(cloud.auth)}>יציאה</button></>}
          <br /><small style={{ opacity: .6 }}>גרסה {VERSION} · {BUILD_DATE}</small>
        </div>
      </aside>

      <main className="main">
        {booksErr && <div className="mg-note bad" style={{ marginBottom: 14 }}>{booksErr}</div>}
        {stale && cur !== 'settings' && (
          <div className="mg-note warn" style={{ marginBottom: 14 }}>
            הנתונים שמורים רק בדפדפן הזה{lastBackup ? `, והגיבוי האחרון נעשה ב-${heDate(lastBackup.slice(0, 10))}` : ' ועדיין לא נעשה גיבוי'}.{' '}
            <button className="mg-linkish" onClick={() => setCur('settings')}>לגיבוי או למעבר לענן</button></div>
        )}
        {books === null && <div className="mg-empty">טוען את העסקים…</div>}

        {cur === 'settings' && (
          <SettingsView user={user} flash={flash}
                        onRestored={() => { setDatas({}); refreshBooks(); }} />
        )}

        {cur !== 'settings' && books && !books.length && !booksErr && <Welcome onNew={(preset) => setBookForm(preset)} />}

        {cur === 'all' && books && books.length > 0 && (
          <AllView books={books} datas={datas} loading={loading} onOpen={setCur} />
        )}

        {book && (datas[book.id]
          ? <BookView key={book.id} book={book} data={datas[book.id]} patch={patch(book.id)} flash={flash}
                      onReload={() => ensure(book, true)} onEditBook={() => setBookForm(book)}
                      onDeleteBook={() => deleteBook(book)} />
          : <div className="mg-empty">טוען את {book.name}…</div>)}
      </main>

      {bookForm && (
        <BookForm rec={bookForm} me={user.email} count={books?.length || 0}
                  onClose={() => setBookForm(null)}
                  onSave={async (b) => { if (await saveBook(b)) { setBookForm(null); setCur(b.id); } }} />
      )}
      {msg && <div className="flash">{msg}</div>}
    </div>
  );
}

function Welcome({ onNew }) {
  return (
    <div className="mg-card" style={{ maxWidth: 640 }}>
      <h2 style={{ marginTop: 0, fontFamily: 'Frank Ruhl Libre,serif' }}>ברוך הבא</h2>
      <p>כל עסק מנוהל כספר נפרד, עם סוג עוסק ומע״מ משלו. בדף "כל העסקים" רואים את כולם יחד.</p>
      <div style={row}>
        <button className="mg-btn" onClick={() => onNew({ name: 'החנות', kind: 'store' })}>הוסף את החנות</button>
        <button className="mg-btn ghost" onClick={() => onNew({ name: 'הקליניקה', kind: 'clinic' })}>הוסף קליניקה</button>
        <button className="mg-btn ghost" onClick={() => onNew({})}>עסק אחר</button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------ business form */
function BookForm({ rec, me, count, onSave, onClose }) {
  const [f, setF] = useState(() => ({
    id: uid('book'), name: '', kind: 'other', legalName: '', taxId: '', dealerType: 'licensed', vatRate: 18,
    color: BOOK_COLORS[count % BOOK_COLORS.length], order: count, owners: cloud ? [me.toLowerCase()] : [],
    ...rec, ownersText: (rec.owners || (cloud ? [me.toLowerCase()] : [])).join(', ')
  }));
  const set = (k, v) => setF(p => ({ ...p, [k]: v }));
  const submit = () => {
    const { ownersText, ...b } = f;
    onSave({ ...b, vatRate: Number(b.vatRate) || 0, owners: ownersText.split(/[,\s]+/).filter(Boolean) });
  };
  return (
    <Box title={rec.id ? 'הגדרות העסק' : 'עסק חדש'} onClose={onClose} wide
         footer={<><button className="mg-btn" disabled={!String(f.name).trim()} onClick={submit}>שמור</button>
                   <button className="mg-btn ghost" onClick={onClose}>ביטול</button></>}>
      <div style={grid}>
        <Field label="שם העסק (לתצוגה)"><input value={f.name} onChange={e => set('name', e.target.value)} /></Field>
        <Field label="סוג"><select value={f.kind} onChange={e => set('kind', e.target.value)}>
          {Object.entries(KINDS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
        <Field label="שם משפטי"><input value={f.legalName} onChange={e => set('legalName', e.target.value)} /></Field>
        <Field label="ח.פ. / ע.מ."><input dir="ltr" value={f.taxId} onChange={e => set('taxId', e.target.value)} /></Field>
        <Field label="סוג עוסק"><select value={f.dealerType} onChange={e => set('dealerType', e.target.value)}>
          {Object.entries(DEALERS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
        {f.dealerType !== 'exempt' && <Field label="שיעור מע״מ (%)"><input inputMode="decimal" value={f.vatRate} onChange={e => set('vatRate', e.target.value)} /></Field>}
        <Field label="צבע"><div style={{ display: 'flex', gap: 6 }}>
          {BOOK_COLORS.map(c => <button key={c} type="button" onClick={() => set('color', c)}
            style={{ width: 28, height: 28, borderRadius: '50%', background: c, border: f.color === c ? '3px solid #e8c98a' : '2px solid #fff', cursor: 'pointer', boxShadow: '0 0 0 1px #ddd' }} />)}
        </div></Field>
      </div>
      {cloud && <div style={{ marginTop: 12 }}>
        <Field label="מי מורשה לגשת לספר (אימיילים, מופרדים בפסיק)">
          <input dir="ltr" value={f.ownersText} onChange={e => set('ownersText', e.target.value)} /></Field>
      </div>}
      <div className="mg-note" style={{ marginTop: 12 }}>
        שני עסקים עם אותו ע.מ. מדווחים מע״מ יחד, ובדף "כל העסקים" הם מאוחדים בדוח המע״מ.
        {cloud && ' אפשר להוסיף כאן את רואה החשבון: הוא נכנס עם משתמש משלו ורואה רק את הספרים שלו.'}
      </div>
    </Box>
  );
}

/* ---------------------------------------------------------- backup & cloud */
function SettingsView({ user, flash, onRestored }) {
  const [busy, setBusy] = useState(false);
  const [cfgText, setCfgText] = useState('');
  const lastBackup = lsGet(BACKUP_KEY, null);

  const backup = async () => {
    setBusy(true);
    try {
      const data = await exportAll(user.email);
      const stamp = new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
      saveJSON(`tizon-books-backup-${stamp}.json`, data);
      lsSet(BACKUP_KEY, new Date().toISOString());
      flash(`הגיבוי ירד · ${data.books.length} עסקים`);
    } catch (e) { flash('הגיבוי נכשל · ' + (e?.message || '')); }
    setBusy(false);
  };
  const restore = async (file) => {
    if (!file) return;
    setBusy(true);
    try {
      const r = await importAll(JSON.parse(await file.text()), cloud ? user.email : '');
      flash(`שוחזרו ${r.books} עסקים ו-${r.records} רשומות`); onRestored();
    } catch (e) { flash('השחזור נכשל · ' + (e?.message || '')); }
    setBusy(false);
  };
  const connect = () => {
    const c = parseFirebaseConfig(cfgText);
    if (!c) { flash('לא זיהיתי apiKey ו-projectId בטקסט שהודבק'); return; }
    if (c.projectId === 'tizonshoponline' && !window.confirm('זה הפרויקט של החנות. המערכת צריכה פרויקט נפרד. להמשיך בכל זאת?')) return;
    lsSet(CLOUD_KEY, c); location.reload();
  };
  const moveUp = async () => {
    if (!window.confirm('להעתיק את כל הנתונים שנשמרו במחשב הזה לענן?')) return;
    setBusy(true);
    try {
      const data = await exportAll('', local);
      const r = await importAll(data, user.email);
      flash(`הועברו ${r.books} עסקים ו-${r.records} רשומות לענן`); onRestored();
    } catch (e) { flash('ההעברה נכשלה · ' + (e?.code || e?.message || '')); }
    setBusy(false);
  };

  return (
    <>
      <div className="mg-h" style={{ '--h1': '#16271e', '--h2': '#3b5a45' }}>
        <div><h2>גיבוי וענן</h2><div className="sub">גרסה {VERSION} · {cloud ? `מחובר לענן · ${cloud.cfg.projectId}` : 'הנתונים נשמרים במחשב הזה'}</div></div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(320px,1fr))', gap: 16 }}>
        <div className="mg-card">
          <h3 style={{ marginTop: 0 }}>גיבוי</h3>
          <p style={{ marginTop: 0 }}>קובץ אחד עם כל העסקים וכל הרשומות. אפשר לשחזר ממנו בכל מחשב, גם אחרי מעבר לענן.</p>
          <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 10 }}>
            גיבוי אחרון מהמכשיר הזה: {lastBackup ? heDate(lastBackup.slice(0, 10)) : 'עוד לא'}</div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button className="mg-btn" disabled={busy} onClick={backup}>⬇ הורד גיבוי</button>
            <label className="mg-btn ghost" style={{ cursor: 'pointer' }}>⬆ שחזר מגיבוי
              <input type="file" accept=".json,application/json" hidden onChange={e => { restore(e.target.files?.[0]); e.target.value = ''; }} /></label>
          </div>
          <div className="mg-note" style={{ marginTop: 12 }}>שחזור מוסיף ומעדכן רשומות לפי המזהה שלהן. הוא לא מוחק רשומות שכבר קיימות.</div>
        </div>

        <div className="mg-card">
          <h3 style={{ marginTop: 0 }}>ענן</h3>
          {!cloud ? (
            <>
              <p style={{ marginTop: 0 }}>
                כרגע הכול נשמר בדפדפן הזה בלבד. כדי לעבוד מכל מכשיר, מחברים פרויקט Firebase <b>נפרד</b>, לא הפרויקט של החנות:
              </p>
              <ol style={{ paddingInlineStart: 18, lineHeight: 1.8, fontSize: 14, marginTop: 0 }}>
                <li>ב-console.firebase.google.com יוצרים פרויקט חדש, למשל tizon-books.</li>
                <li>Authentication ← Sign-in method ← מפעילים Email/Password.</li>
                <li>Firestore Database ← Create database.</li>
                <li>Firestore ← Rules ← מדביקים את הקובץ firestore.rules שמגיע עם המערכת ← Publish.</li>
                <li>Project settings ← Your apps ← Web ← מעתיקים את ה-firebaseConfig ומדביקים כאן.</li>
              </ol>
              <textarea rows={6} dir="ltr" value={cfgText} onChange={e => setCfgText(e.target.value)}
                        placeholder={'const firebaseConfig = {\n  apiKey: "…",\n  projectId: "…",\n  …\n};'} />
              <div style={{ marginTop: 10 }}><button className="mg-btn" disabled={!cfgText.trim()} onClick={connect}>חבר לענן</button></div>
              <div className="mg-note" style={{ marginTop: 12 }}>הנתונים שכבר נשמרו במחשב לא נמחקים. אחרי הכניסה לענן יופיע כפתור להעביר אותם.</div>
            </>
          ) : (
            <>
              <p style={{ marginTop: 0 }}>מחובר לפרויקט <b dir="ltr">{cloud.cfg.projectId}</b> כ-<b dir="ltr">{user.email}</b>.</p>
              {hasLocalData() && (
                <div className="mg-note warn" style={{ marginBottom: 12 }}>
                  יש במחשב הזה נתונים מלפני המעבר לענן.{' '}
                  <button className="mg-btn sm" disabled={busy} onClick={moveUp}>העבר אותם לענן</button></div>
              )}
              <button className="mg-btn ghost" onClick={() => { if (window.confirm('לנתק את הענן במכשיר הזה? הנתונים בענן נשארים שם.')) { localStorage.removeItem(CLOUD_KEY); location.reload(); } }}>
                נתק את הענן במכשיר הזה</button>
            </>
          )}
        </div>
      </div>
    </>
  );
}
/* ============================================================ all businesses */
function AllView({ books, datas, loading, onOpen }) {
  const [mode, setMode] = useState('month');
  const [month, setMonth] = useState(thisMonth());
  const y = month.slice(0, 4);
  const [from, to] = mode === 'month' ? [month, month]
    : mode === 'bi' ? [biStart(month), addMonths(biStart(month), 1)]
    : mode === 'ytd' ? [y + '-01', month] : [y + '-01', y + '-12'];
  const label = from === to ? monthName(from) : `${monthName(from)}–${monthName(to)}`;

  const rows = books.map(b => {
    const d = datas[b.id];
    if (!d) return { b, pending: true };
    const L = buildLedger(b, d);
    return { b, d, L, t: totals(L, from, to), a: alertsOf(d, L) };
  });
  const ready = rows.filter(r => !r.pending);
  const sum = (k) => ready.reduce((a, r) => a + r.t[k], 0);

  /* VAT is reported per dealer: businesses under one tax id file one return. */
  const vatGroups = {};
  ready.filter(r => r.L.rate > 0).forEach(r => {
    const k = String(r.b.taxId || '').trim() || 'book:' + r.b.id;
    const g = vatGroups[k] = vatGroups[k] || { taxId: r.b.taxId, names: [], incVat: 0, expVat: 0 };
    g.names.push(r.b.name); g.incVat += r.t.incVat; g.expVat += r.t.expVat;
  });

  const months = Array.from({ length: 12 }, (_, i) => addMonths(thisMonth(), i - 11));
  const series = months.map(m => ({ m, parts: ready.map(r => ({ b: r.b, v: totals(r.L, m, m) })) }));
  const top = Math.max(1, ...series.map(s => Math.max(s.parts.reduce((a, p) => a + p.v.incNet, 0), s.parts.reduce((a, p) => a + p.v.expNet, 0))));

  const alerts = ready.flatMap(r => {
    const out = [];
    if (r.d.storeErr) out.push({ r, t: r.d.storeErr, bad: true });
    if (r.d.errors?.length) out.push({ r, t: 'חלק מהנתונים לא נטענו. בדוק את חוקי ה-Firestore.', bad: true });
    if (r.a.noDocOrders) out.push({ r, t: `${r.a.noDocOrders} הזמנות ששולמו בלי חשבונית` });
    if (r.a.unmatched) out.push({ r, t: `${r.a.unmatched} שורות בנק לא מותאמות` });
    if (r.a.noDocExp) out.push({ r, t: `${r.a.noDocExp} הוצאות בלי מספר חשבונית` });
    if (r.a.review) out.push({ r, t: `${r.a.review} רשומות מיובאות לבדיקה` });
    return out;
  });

  return (
    <>
      <div className="mg-h" style={{ '--h1': '#16271e', '--h2': '#3b5a45' }}>
        <div><h2>כל העסקים</h2><div className="sub">{label} · {books.length} עסקים</div></div>
      </div>

      <div style={{ ...row, marginBottom: 14 }}>
        <Field label="תקופה"><select value={mode} onChange={e => setMode(e.target.value)}>
          <option value="month">חודש</option><option value="bi">תקופת מע״מ (חודשיים)</option>
          <option value="ytd">מתחילת השנה</option><option value="year">שנה מלאה</option></select></Field>
        <Field label={mode === 'year' || mode === 'ytd' ? 'עד חודש' : 'חודש'}>
          <input type="month" value={month} onChange={e => e.target.value && setMonth(e.target.value)} /></Field>
        <button className="mg-btn ghost sm" onClick={() => downloadCSV(`all-${from}_${to}.csv`, [
          ['עסק', 'הכנסות לפני מע״מ', 'הוצאות לפני מע״מ', 'רווח', 'מע״מ עסקאות', 'מע״מ תשומות'],
          ...ready.map(r => [r.b.name, r2(r.t.incNet), r2(r.t.expNet), r2(r.t.profit), r2(r.t.incVat), r2(r.t.expVat)]),
          ['סה״כ', r2(sum('incNet')), r2(sum('expNet')), r2(sum('profit')), r2(sum('incVat')), r2(sum('expVat'))]
        ])}>⬇ ייצוא</button>
      </div>

      <div className="mg-stats" style={{ marginBottom: 16 }}>
        <div className="mg-stat"><div className="lb">הכנסות (לפני מע״מ)</div><div className="vl">{fmt(sum('incNet'))}</div><div className="dl">כל העסקים · {label}</div></div>
        <div className="mg-stat"><div className="lb">הוצאות (לפני מע״מ)</div><div className="vl">{fmt(sum('expNet'))}</div></div>
        <div className="mg-stat"><div className="lb">רווח</div><div className="vl" style={sum('profit') < 0 ? { color: 'var(--bad)' } : undefined}>{fmt(sum('profit'))}</div></div>
        <div className="mg-stat"><div className="lb">מע״מ נטו</div><div className="vl">{fmt(sum('vatDue'))}</div><div className="dl">{sum('vatDue') >= 0 ? 'לתשלום' : 'להחזר'}</div></div>
      </div>

      <div className="mg-tblwrap" style={{ marginBottom: 16 }}><table className="mg-tbl">
        <thead><tr><th>עסק</th><th>סוג</th><th>הכנסות</th><th>הוצאות</th><th>רווח</th><th>מע״מ</th><th></th></tr></thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.b.id}>
              <td><span className="dot" style={{ background: r.b.color, display: 'inline-block', marginInlineEnd: 8 }} /><b>{r.b.name}</b></td>
              <td><span className="mg-chip">{KINDS[r.b.kind] || 'אחר'}</span> <span className="mg-chip">{DEALERS[r.b.dealerType]}</span></td>
              {r.pending
                ? <td colSpan={4} style={{ color: 'var(--muted)' }}>{loading[r.b.id] ? 'טוען…' : '—'}</td>
                : <><td>{fmt(r.t.incNet)}</td><td>{fmt(r.t.expNet)}</td>
                    <td style={{ color: r.t.profit < 0 ? 'var(--bad)' : undefined, fontWeight: 700 }}>{fmt(r.t.profit)}</td>
                    <td>{r.L.rate > 0 ? fmt(r.t.vatDue) : 'פטור'}</td></>}
              <td><button className="mg-btn ghost sm" onClick={() => onOpen(r.b.id)}>פתח</button></td>
            </tr>
          ))}
        </tbody>
        <tfoot><tr><td colSpan={2}>סה״כ</td><td>{fmt(sum('incNet'))}</td><td>{fmt(sum('expNet'))}</td><td>{fmt(sum('profit'))}</td><td>{fmt(sum('vatDue'))}</td><td></td></tr></tfoot>
      </table></div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(320px,1fr))', gap: 16, marginBottom: 16 }}>
        <div className="mg-card">
          <h3 style={{ marginTop: 0 }}>מע״מ לפי עוסק · {label}</h3>
          {Object.values(vatGroups).map((g, i) => (
            <div key={i} style={{ padding: '10px 0', borderBottom: '1px solid #f0ebe0' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700 }}>
                <span>{g.taxId ? <span dir="ltr">{g.taxId}</span> : 'ללא ע.מ.'}</span>
                <span dir="ltr">{fmt(g.incVat - g.expVat)}</span></div>
              <div style={{ fontSize: 13, color: 'var(--muted)' }}>{g.names.join(' + ')} · עסקאות {fmt(g.incVat)} · תשומות {fmt(g.expVat)}</div>
            </div>
          ))}
          {!Object.keys(vatGroups).length && <div className="mg-empty">כל העסקים מוגדרים כפטורים.</div>}
          {Object.values(vatGroups).some(g => !g.taxId) && (
            <div className="mg-note warn" style={{ marginTop: 10 }}>לעסקים בלי ע.מ. בהגדרות אי אפשר לדעת אם הם מדווחים יחד. כדאי למלא.</div>
          )}
        </div>
        <div className="mg-card">
          <h3 style={{ marginTop: 0 }}>מה דורש טיפול</h3>
          {alerts.map((x, i) => (
            <div key={i} className={'mg-note' + (x.bad ? ' bad' : ' warn')} style={{ marginBottom: 8 }}>
              <b>{x.r.b.name}:</b> {x.t}{' '}<button className="mg-linkish" onClick={() => onOpen(x.r.b.id)}>פתח</button></div>
          ))}
          {!alerts.length && <div className="mg-empty">הכול מסודר.</div>}
        </div>
      </div>

      <div className="mg-card">
        <h3 style={{ marginTop: 0 }}>12 חודשים · הכנסות לפי עסק (ימין) מול הוצאות (שמאל)</h3>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height: 190, padding: '8px 0' }}>
          {series.map(s => (
            <div key={s.m} style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, height: '100%' }}>
              <div style={{ flex: 1, display: 'flex', alignItems: 'flex-end', gap: 2, width: '100%', justifyContent: 'center' }}>
                <div style={{ width: '42%', display: 'flex', flexDirection: 'column-reverse', height: '100%' }}>
                  {s.parts.map(p => <div key={p.b.id} title={`${p.b.name} · ${fmt(p.v.incNet)}`}
                    style={{ height: `${Math.max(0, p.v.incNet) / top * 100}%`, background: p.b.color }} />)}
                </div>
                <div style={{ width: '30%', display: 'flex', flexDirection: 'column-reverse', height: '100%' }}>
                  <div title={`הוצאות · ${fmt(s.parts.reduce((a, p) => a + p.v.expNet, 0))}`}
                       style={{ height: `${s.parts.reduce((a, p) => a + p.v.expNet, 0) / top * 100}%`, background: '#d8cfbd', borderRadius: '3px 3px 0 0' }} />
                </div>
              </div>
              <div className="mlab">{monthName(s.m)}</div>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', fontSize: 13, color: 'var(--muted)' }}>
          {books.map(b => <span key={b.id}><span style={{ color: b.color }}>■</span> {b.name}</span>)}
          <span><span style={{ color: '#d8cfbd' }}>■</span> הוצאות (כל העסקים)</span>
        </div>
      </div>
    </>
  );
}

/* ================================================================ one book */
function BookView({ book, data, patch, flash, onReload, onEditBook, onDeleteBook }) {
  const [sub, setSub] = useState('dash');
  const [edit, setEdit] = useState(null);
  const cols = useMemo(() => Object.fromEntries(COLS.map(c => [c, bookCol(book.id, c)])), [book.id]);
  const ledger = useMemo(() => buildLedger(book, data), [book, data]);
  const rate = ledger.rate;
  const tot = (f, t) => totals(ledger, f, t);
  const alerts = alertsOf(data, ledger);
  const suppliers = data.suppliers || [];
  const supName = (id) => suppliers.find(s => s.id === id)?.name || '';

  const save = async (name, rec) => {
    const r = clean({ ...rec, updatedAt: new Date().toISOString() });
    try { await withTimeout(cols[name].put(r.id, r), 12000); }
    catch { flash('השמירה נכשלה. בדוק את החיבור ואת חוקי Firestore.'); return false; }
    patch(name, list => [...list.filter(x => x.id !== r.id), r]);
    return true;
  };
  const remove = async (name, id, what) => {
    if (!window.confirm(`למחוק את ${what}?`)) return;
    try { await withTimeout(cols[name].del(id), 12000); patch(name, list => list.filter(x => x.id !== id)); flash('נמחק'); }
    catch { flash('המחיקה נכשלה'); }
  };

  const SUBS = [['dash', 'סקירה'], ['income', 'הכנסות'], ['expenses', 'הוצאות'], ['suppliers', 'ספקים'],
    ['bank', 'בנק' + (alerts.unmatched ? ` (${alerts.unmatched})` : '')], ['vat', 'מע״מ'], ['pnl', 'רווח והפסד'], ['import', 'ייבוא']];

  return (
    <>
      <div className="mg-h" style={{ '--h1': book.color || '#1f5a3d', '--h2': '#3b5a45' }}>
        <div><h2>{book.name}</h2>
          <div className="sub">{DEALERS[book.dealerType]}{book.taxId ? ' · ' + book.taxId : ''}{rate > 0 ? ` · מע״מ ${rate}%` : ''}
            {book.tenant ? ` · מקושר לחנות ${book.tenant}` : ''}</div></div>
        <button className="mg-btn ghost" onClick={() => setEdit({ kind: 'expense', rec: null })}>＋ הוצאה</button>
        <button className="mg-btn ghost" onClick={() => setEdit({ kind: 'income', rec: null })}>＋ הכנסה</button>
        <button className="mg-btn ghost" onClick={onEditBook}>הגדרות</button>
      </div>

      {data.storeErr && <div className="mg-note bad" style={{ marginBottom: 12 }}>{data.storeErr}</div>}
      {data.errors?.length > 0 && <div className="mg-note bad" style={{ marginBottom: 12 }}>
        חלק מהנתונים לא נטענו ({data.errors.join(', ')}). בדוק שחוקי ה-Firestore המעודכנים פורסמו.{' '}
        <button className="mg-linkish" onClick={onReload}>נסה שוב</button></div>}

      <div className="mg-tabs" style={{ marginBottom: 16 }}>
        {SUBS.map(([k, l]) => <button key={k} className={'mg-tab' + (sub === k ? ' on' : '')} onClick={() => setSub(k)}>{l}</button>)}
      </div>

      {sub === 'dash' && <Dash totals={tot} rate={rate} alerts={alerts} onSub={setSub} linked={!!book.tenant} />}
      {sub === 'income' && <IncomeList income={ledger.income} linked={!!book.tenant}
        onEdit={(r) => setEdit({ kind: 'income', rec: r })} onDel={(r) => remove('incomes', r.id, 'ההכנסה')} />}
      {sub === 'expenses' && <ExpenseList outgo={ledger.outgo} supName={supName}
        onEdit={(r) => setEdit({ kind: 'expense', rec: r })} onDel={(r) => remove('expenses', r.id, 'ההוצאה')} />}
      {sub === 'suppliers' && <SupplierList suppliers={suppliers} outgo={ledger.outgo}
        onEdit={(r) => setEdit({ kind: 'supplier', rec: r })} onDel={(r) => remove('suppliers', r.id, 'הספק')} />}
      {sub === 'bank' && <BankTab bank={data.banktx || []} income={ledger.income} outgo={ledger.outgo} flash={flash}
        onSave={(r) => save('banktx', r)} onDel={(r) => remove('banktx', r.id, 'השורה')}
        onBulk={async (recs) => { let ok = 0; for (const r of recs) if (await save('banktx', r)) ok++; return ok; }} />}
      {sub === 'vat' && <VatTab totals={tot} rate={rate} book={book} />}
      {sub === 'pnl' && <PnlTab totals={tot} supName={supName} book={book} />}
      {sub === 'import' && <ImportTab data={data} cols={cols} flash={flash} onDone={onReload} onDeleteBook={onDeleteBook} />}

      {edit?.kind === 'income' && <IncomeForm rec={edit.rec} rate={rate} onClose={() => setEdit(null)}
        onSave={async (r) => { if (await save('incomes', r)) { flash('ההכנסה נשמרה'); setEdit(null); } }} />}
      {edit?.kind === 'expense' && <ExpenseForm rec={edit.rec} rate={rate} suppliers={suppliers} onClose={() => setEdit(null)}
        onNewSupplier={(s) => save('suppliers', s)}
        onSave={async (r) => { if (await save('expenses', r)) { flash('ההוצאה נשמרה'); setEdit(null); } }} />}
      {edit?.kind === 'supplier' && <SupplierForm rec={edit.rec} onClose={() => setEdit(null)}
        onSave={async (r) => { if (await save('suppliers', r)) { flash('הספק נשמר'); setEdit(null); } }} />}
    </>
  );
}

/* ------------------------------------------------------------------- סקירה */
function Dash({ totals, rate, alerts, onSub, linked }) {
  const [month, setMonth] = useState(thisMonth());
  const t = totals(month, month);
  const year = month.slice(0, 4);
  const y = totals(year + '-01', year + '-12');
  const months = Array.from({ length: 12 }, (_, i) => addMonths(month, i - 11));
  const series = months.map(m => { const x = totals(m, m); return { m, inc: x.incNet, exp: x.expNet }; });
  const top = Math.max(1, ...series.map(s => Math.max(s.inc, s.exp)));
  const pStart = biStart(month);
  const vp = totals(pStart, addMonths(pStart, 1));

  return (
    <>
      <div style={{ ...row, marginBottom: 14 }}>
        <Field label="חודש"><input type="month" value={month} onChange={e => e.target.value && setMonth(e.target.value)} /></Field>
      </div>
      <div className="mg-stats" style={{ marginBottom: 18 }}>
        <div className="mg-stat"><div className="lb">הכנסות (לפני מע״מ)</div><div className="vl">{fmt(t.incNet)}</div>
          <div className="dl">{t.inc.length} תנועות · השנה {fmt(y.incNet)}</div></div>
        <div className="mg-stat"><div className="lb">הוצאות (לפני מע״מ)</div><div className="vl">{fmt(t.expNet)}</div>
          <div className="dl">{t.exp.length} תנועות · השנה {fmt(y.expNet)}</div></div>
        <div className="mg-stat"><div className="lb">רווח</div>
          <div className="vl" style={t.profit < 0 ? { color: 'var(--bad)' } : undefined}>{fmt(t.profit)}</div>
          <div className="dl">השנה {fmt(y.profit)}</div></div>
        <div className="mg-stat"><div className="lb">{rate > 0 ? `מע״מ ${monthName(pStart)}–${monthName(addMonths(pStart, 1))}` : 'מע״מ'}</div>
          <div className="vl">{rate > 0 ? fmt(vp.vatDue) : '—'}</div>
          <div className="dl">{rate > 0 ? (vp.vatDue >= 0 ? 'לתשלום' : 'להחזר') : 'עוסק פטור'}</div></div>
      </div>

      {(alerts.noDocOrders > 0 || alerts.unmatched > 0 || alerts.noDocExp > 0 || alerts.review > 0) && (
        <div className="mg-card" style={{ marginBottom: 18 }}>
          <h3 style={{ marginTop: 0 }}>מה דורש טיפול</h3>
          {alerts.noDocOrders > 0 && <div className="mg-note warn" style={{ marginBottom: 8 }}>
            {alerts.noDocOrders} הזמנות ששולמו ועדיין אין להן חשבונית. מפיקים במסך ההזמנות בקונסולת החנות.</div>}
          {alerts.unmatched > 0 && <div className="mg-note warn" style={{ marginBottom: 8 }}>
            {alerts.unmatched} שורות בנק שלא הותאמו. <button className="mg-linkish" onClick={() => onSub('bank')}>להתאמה</button></div>}
          {alerts.noDocExp > 0 && <div className="mg-note warn" style={{ marginBottom: 8 }}>
            {alerts.noDocExp} הוצאות בלי מספר חשבונית. בלי חשבונית אי אפשר לקזז את המע״מ שלהן.{' '}
            <button className="mg-linkish" onClick={() => onSub('expenses')}>להוצאות</button></div>}
          {alerts.review > 0 && <div className="mg-note warn">{alerts.review} רשומות שיובאו מהמערכת הישנה מסומנות לבדיקה.</div>}
        </div>
      )}

      <div className="mg-card">
        <h3 style={{ marginTop: 0 }}>12 חודשים · הכנסות מול הוצאות (לפני מע״מ)</h3>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height: 180, padding: '8px 0' }}>
          {series.map(s => (
            <div key={s.m} style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, height: '100%' }}
                 title={`${monthName(s.m)} · הכנסות ${fmt(s.inc)} · הוצאות ${fmt(s.exp)}`}>
              <div style={{ flex: 1, display: 'flex', alignItems: 'flex-end', gap: 2, width: '100%', justifyContent: 'center' }}>
                <div style={{ width: '40%', height: `${Math.max(0, s.inc) / top * 100}%`, background: 'var(--green2)', borderRadius: '4px 4px 0 0' }} />
                <div style={{ width: '40%', height: `${s.exp / top * 100}%`, background: '#d9822b', borderRadius: '4px 4px 0 0' }} />
              </div>
              <div className="mlab">{monthName(s.m)}</div>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 14, fontSize: 13, color: 'var(--muted)' }}>
          <span><span style={{ color: 'var(--green2)' }}>■</span> הכנסות{linked ? ' (כולל החנות)' : ''}</span>
          <span><span style={{ color: '#d9822b' }}>■</span> הוצאות</span>
        </div>
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ הכנסות */
function IncomeList({ income, linked, onEdit, onDel }) {
  const [month, setMonth] = useState('');
  const [src, setSrc] = useState('all');
  const [q, setQ] = useState('');
  const list = income.filter(i => (!month || (i.date || '').startsWith(month))
    && (src === 'all' || (src === 'shop' ? i.src === 'shop' : i.src !== 'shop'))
    && (!q || (i.desc + ' ' + (i.docNo || '') + ' ' + (i.customer || '')).includes(q.trim())));
  const sum = list.reduce((a, i) => a + i.gross, 0), vat = list.reduce((a, i) => a + i.vat, 0);
  return (
    <>
      <div style={{ ...row, marginBottom: 12 }}>
        <Field label="חודש"><input type="month" value={month} onChange={e => setMonth(e.target.value)} /></Field>
        {linked && <Field label="מקור"><select value={src} onChange={e => setSrc(e.target.value)}>
          <option value="all">הכול</option><option value="shop">מהחנות</option><option value="manual">ידני</option></select></Field>}
        <Field label="חיפוש"><input value={q} onChange={e => setQ(e.target.value)} placeholder="שם, מספר, מסמך" /></Field>
        <button className="mg-btn ghost sm" onClick={() => downloadCSV(`income-${month || 'all'}.csv`, [
          ['תאריך', 'תיאור', 'לקוח', 'קטגוריה', 'אמצעי תשלום', 'מסמך', 'לפני מע״מ', 'מע״מ', 'סה״כ', 'מקור'],
          ...list.map(i => [i.date, i.desc, i.customer || '', i.cat, i.pay, i.docNo, r2(i.gross - i.vat), i.vat, i.gross, i.src === 'shop' ? 'חנות' : 'ידני'])
        ])}>⬇ ייצוא</button>
      </div>
      {linked && <div className="mg-note" style={{ marginBottom: 12 }}>
        הזמנות מהחנות נכנסות לכאן מעצמן ברגע שהן מסומנות כשולמו. את החשבונית שלהן מפיקים בקונסולת החנות.
      </div>}
      <div className="mg-tblwrap"><table className="mg-tbl">
        <thead><tr><th>תאריך</th><th>תיאור</th><th>קטגוריה</th><th>תשלום</th><th>מסמך</th><th>לפני מע״מ</th><th>מע״מ</th><th>סה״כ</th><th></th></tr></thead>
        <tbody>
          {list.map(i => (
            <tr key={i.id}>
              <td>{heDate(i.date)}</td>
              <td>{i.desc}{i.customer ? <span style={{ color: 'var(--muted)' }}> · {i.customer}</span> : null}
                {i.review && <span className="mg-chip warn" style={{ marginInlineStart: 6 }}>לבדיקה</span>}</td>
              <td><span className={'mg-chip ' + (i.src === 'shop' ? 'ok' : '')}>{i.cat}</span></td>
              <td>{i.pay || '—'}</td>
              <td>{i.docNo || <span style={{ color: 'var(--warn)' }}>חסר</span>}</td>
              <td>{fmt(i.gross - i.vat)}</td><td>{fmt(i.vat)}</td><td><b>{fmt(i.gross)}</b></td>
              <td>{i.src !== 'shop' && <div style={{ display: 'flex', gap: 4 }}>
                <button className="mg-btn ghost sm" onClick={() => onEdit(i)}>✎</button>
                <button className="mg-btn ghost sm" onClick={() => onDel(i)}>🗑</button></div>}</td>
            </tr>
          ))}
          {!list.length && <tr><td colSpan={9}><div className="mg-empty">אין הכנסות בסינון הזה.</div></td></tr>}
        </tbody>
      </table></div>
      <div style={{ display: 'flex', flexWrap: 'wrap', marginTop: 10, gap: 18, fontSize: 14 }}>
        <span>סה״כ: <b>{fmt(sum)}</b></span><span>מתוכו מע״מ: <b>{fmt(vat)}</b></span><span>לפני מע״מ: <b>{fmt(sum - vat)}</b></span>
      </div>
    </>
  );
}

function IncomeForm({ rec, rate, onSave, onClose }) {
  const [f, setF] = useState(() => ({
    id: uid('inc'), date: todayIso(), desc: '', cat: INC_CATS[0], pay: PAY_METHODS[0],
    gross: '', noVat: false, docNo: '', customer: '', ...(rec || {})
  }));
  const set = (k, v) => setF(p => ({ ...p, [k]: v }));
  const g = Number(f.gross) || 0;
  const vat = f.noVat ? 0 : vatOf(g, rate);
  const ok = String(f.desc).trim() && g > 0 && f.date;
  return (
    <Box title={rec ? 'עריכת הכנסה' : 'הכנסה חדשה'} onClose={onClose} wide
         footer={<><button className="mg-btn" disabled={!ok}
                           onClick={() => onSave({ ...f, src: f.src === 'erp' ? 'erp' : 'manual', gross: g, vat, desc: String(f.desc).trim(), review: false })}>שמור</button>
                   <button className="mg-btn ghost" onClick={onClose}>ביטול</button></>}>
      <div style={grid}>
        <Field label="תאריך"><input type="date" value={f.date} onChange={e => set('date', e.target.value)} /></Field>
        <Field label="תיאור"><input value={f.desc} onChange={e => set('desc', e.target.value)} placeholder="טיפול דיקור" /></Field>
        <Field label="לקוח"><input value={f.customer} onChange={e => set('customer', e.target.value)} /></Field>
        <Field label="קטגוריה"><select value={f.cat} onChange={e => set('cat', e.target.value)}>{INC_CATS.map(c => <option key={c}>{c}</option>)}</select></Field>
        <Field label="אמצעי תשלום"><select value={f.pay} onChange={e => set('pay', e.target.value)}>{PAY_METHODS.map(c => <option key={c}>{c}</option>)}</select></Field>
        <Field label="מספר מסמך (חשבונית / קבלה)"><input value={f.docNo} onChange={e => set('docNo', e.target.value)} /></Field>
        <Field label="סכום כולל מע״מ (₪)"><input inputMode="decimal" value={f.gross} onChange={e => set('gross', e.target.value)} /></Field>
      </div>
      {rate > 0 && <label style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 10, fontSize: 14 }}>
        <input type="checkbox" style={{ width: 'auto' }} checked={!!f.noVat} onChange={e => set('noVat', e.target.checked)} />הכנסה פטורה ממע״מ</label>}
      <div className="mg-note" style={{ marginTop: 12 }}>
        לפני מע״מ <b>{fmt(g - vat)}</b> · מע״מ <b>{fmt(vat)}</b> · סה״כ <b>{fmt(g)}</b>
      </div>
    </Box>
  );
}

/* ------------------------------------------------------------------ הוצאות */
function ExpenseList({ outgo, supName, onEdit, onDel }) {
  const [month, setMonth] = useState('');
  const [cat, setCat] = useState('');
  const list = outgo.filter(e => (!month || (e.date || '').startsWith(month)) && (!cat || e.cat === cat));
  const sum = list.reduce((a, e) => a + e.gross, 0), vat = list.reduce((a, e) => a + e.vat, 0);
  return (
    <>
      <div style={{ ...row, marginBottom: 12 }}>
        <Field label="חודש"><input type="month" value={month} onChange={e => setMonth(e.target.value)} /></Field>
        <Field label="קטגוריה"><select value={cat} onChange={e => setCat(e.target.value)}>
          <option value="">הכול</option>{EXP_CATS.map(c => <option key={c}>{c}</option>)}</select></Field>
        <button className="mg-btn ghost sm" onClick={() => downloadCSV(`expenses-${month || 'all'}.csv`, [
          ['תאריך', 'ספק', 'תיאור', 'קטגוריה', 'אמצעי תשלום', 'מסמך', 'לפני מע״מ', 'מע״מ מוכר', 'סה״כ'],
          ...list.map(e => [e.date, supName(e.supplierId) || e.supplierName || '', e.desc, e.cat, e.pay, e.docNo, r2(e.gross - e.vat), e.vat, e.gross])
        ])}>⬇ ייצוא</button>
      </div>
      <div className="mg-tblwrap"><table className="mg-tbl">
        <thead><tr><th>תאריך</th><th>ספק</th><th>תיאור</th><th>קטגוריה</th><th>מסמך</th><th>לפני מע״מ</th><th>מע״מ</th><th>סה״כ</th><th></th></tr></thead>
        <tbody>
          {list.map(e => (
            <tr key={e.id}>
              <td>{heDate(e.date)}</td>
              <td>{supName(e.supplierId) || e.supplierName || '—'}</td>
              <td>{e.desc}{e.review && <span className="mg-chip warn" style={{ marginInlineStart: 6 }}>לבדיקה</span>}</td>
              <td><span className="mg-chip">{e.cat}</span></td>
              <td>{e.docNo || (e.hasDoc ? 'יש' : <span style={{ color: 'var(--warn)' }}>חסר</span>)}</td>
              <td>{fmt(e.gross - e.vat)}</td><td>{fmt(e.vat)}</td><td><b>{fmt(e.gross)}</b></td>
              <td><div style={{ display: 'flex', gap: 4 }}>
                <button className="mg-btn ghost sm" onClick={() => onEdit(e)}>✎</button>
                <button className="mg-btn ghost sm" onClick={() => onDel(e)}>🗑</button></div></td>
            </tr>
          ))}
          {!list.length && <tr><td colSpan={9}><div className="mg-empty">אין הוצאות בסינון הזה.</div></td></tr>}
        </tbody>
      </table></div>
      <div style={{ display: 'flex', flexWrap: 'wrap', marginTop: 10, gap: 18, fontSize: 14 }}>
        <span>סה״כ: <b>{fmt(sum)}</b></span><span>מע״מ לקיזוז: <b>{fmt(vat)}</b></span><span>לפני מע״מ: <b>{fmt(sum - vat)}</b></span>
      </div>
    </>
  );
}

function ExpenseForm({ rec, rate, suppliers, onSave, onClose, onNewSupplier }) {
  const [f, setF] = useState(() => ({
    id: uid('exp'), date: todayIso(), supplierId: '', desc: '', cat: EXP_CATS[0], pay: PAY_METHODS[0],
    gross: '', vatMode: rate > 0 ? 'full' : 'none', vatManual: '', docNo: '', ...(rec || {})
  }));
  const [newSup, setNewSup] = useState('');
  const set = (k, v) => setF(p => ({ ...p, [k]: v }));
  const g = Number(f.gross) || 0;
  /* Deductible VAT: full, a private car's two thirds, none, or typed in. */
  const vat = rate === 0 ? 0
            : f.vatMode === 'full' ? vatOf(g, rate)
            : f.vatMode === 'car' ? r2(vatOf(g, rate) * 2 / 3)
            : f.vatMode === 'manual' ? r2(Number(f.vatManual) || 0) : 0;
  const ok = String(f.desc).trim() && g > 0 && f.date;
  const pickSupplier = (id) => {
    const s = suppliers.find(x => x.id === id);
    setF(p => ({ ...p, supplierId: id, cat: s?.cat && !rec ? s.cat : p.cat }));
  };
  return (
    <Box title={rec ? 'עריכת הוצאה' : 'הוצאה חדשה'} onClose={onClose} wide
         footer={<><button className="mg-btn" disabled={!ok}
                           onClick={() => onSave({ ...f, gross: g, vat, desc: String(f.desc).trim(), hasDoc: !!f.docNo || !!f.hasDoc, review: false })}>שמור</button>
                   <button className="mg-btn ghost" onClick={onClose}>ביטול</button></>}>
      <div style={grid}>
        <Field label="תאריך"><input type="date" value={f.date} onChange={e => set('date', e.target.value)} /></Field>
        <Field label="ספק"><select value={f.supplierId} onChange={e => pickSupplier(e.target.value)}>
          <option value="">— ללא —</option>{suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select></Field>
        <Field label="או ספק חדש">
          <div style={{ display: 'flex', gap: 6 }}><input value={newSup} onChange={e => setNewSup(e.target.value)} />
            <button type="button" className="mg-btn ghost sm" disabled={!newSup.trim()} onClick={async () => {
              const s = { id: uid('sup'), name: newSup.trim(), cat: f.cat, taxId: '', phone: '', email: '' };
              if (await onNewSupplier(s)) { setF(p => ({ ...p, supplierId: s.id })); setNewSup(''); }
            }}>＋</button></div></Field>
        <Field label="תיאור"><input value={f.desc} onChange={e => set('desc', e.target.value)} /></Field>
        <Field label="קטגוריה"><select value={f.cat} onChange={e => set('cat', e.target.value)}>{EXP_CATS.map(c => <option key={c}>{c}</option>)}</select></Field>
        <Field label="אמצעי תשלום"><select value={f.pay} onChange={e => set('pay', e.target.value)}>{PAY_METHODS.map(c => <option key={c}>{c}</option>)}</select></Field>
        <Field label="מספר חשבונית של הספק"><input value={f.docNo} onChange={e => set('docNo', e.target.value)} /></Field>
        <Field label="סכום כולל מע״מ (₪)"><input inputMode="decimal" value={f.gross} onChange={e => set('gross', e.target.value)} /></Field>
        {rate > 0 && <Field label="מע״מ מוכר לקיזוז"><select value={f.vatMode} onChange={e => set('vatMode', e.target.value)}>
          <option value="full">מלא ({rate}%)</option><option value="car">רכב פרטי (2/3)</option>
          <option value="none">ללא (ספק פטור / חו״ל)</option><option value="manual">סכום ידני</option></select></Field>}
        {rate > 0 && f.vatMode === 'manual' && <Field label="סכום המע״מ"><input inputMode="decimal" value={f.vatManual} onChange={e => set('vatManual', e.target.value)} /></Field>}
      </div>
      <div className="mg-note" style={{ marginTop: 12 }}>
        לפני מע״מ <b>{fmt(g - vat)}</b> · מע״מ לקיזוז <b>{fmt(vat)}</b> · סה״כ <b>{fmt(g)}</b>
      </div>
    </Box>
  );
}

/* ------------------------------------------------------------------- ספקים */
function SupplierList({ suppliers, outgo, onEdit, onDel }) {
  const year = new Date().getFullYear().toString();
  return (
    <>
      <div style={{ marginBottom: 12 }}><button className="mg-btn" onClick={() => onEdit(null)}>＋ ספק חדש</button></div>
      <div className="mg-tblwrap"><table className="mg-tbl">
        <thead><tr><th>שם</th><th>ח.פ. / ע.מ.</th><th>טלפון</th><th>אימייל</th><th>קטגוריה</th><th>השנה</th><th>סה״כ</th><th></th></tr></thead>
        <tbody>
          {[...suppliers].sort((a, b) => (a.name || '').localeCompare(b.name || '', 'he')).map(s => {
            const mine = outgo.filter(e => e.supplierId === s.id);
            return (
              <tr key={s.id}>
                <td><b>{s.name}</b>{s.review && <span className="mg-chip warn" style={{ marginInlineStart: 6 }}>יובא</span>}</td>
                <td dir="ltr" style={{ textAlign: 'right' }}>{s.taxId || '—'}</td>
                <td dir="ltr" style={{ textAlign: 'right' }}>{s.phone || '—'}</td>
                <td>{s.email || '—'}</td><td>{s.cat || '—'}</td>
                <td>{fmt(mine.filter(e => (e.date || '').startsWith(year)).reduce((a, e) => a + e.gross, 0))}</td>
                <td>{fmt(mine.reduce((a, e) => a + e.gross, 0))} <span style={{ color: 'var(--muted)', fontSize: 12 }}>({mine.length})</span></td>
                <td><div style={{ display: 'flex', gap: 4 }}>
                  <button className="mg-btn ghost sm" onClick={() => onEdit(s)}>✎</button>
                  <button className="mg-btn ghost sm" onClick={() => onDel(s)}>🗑</button></div></td>
              </tr>
            );
          })}
          {!suppliers.length && <tr><td colSpan={8}><div className="mg-empty">עוד אין ספקים.</div></td></tr>}
        </tbody>
      </table></div>
    </>
  );
}

function SupplierForm({ rec, onSave, onClose }) {
  const [f, setF] = useState(() => ({ id: uid('sup'), name: '', taxId: '', phone: '', email: '', cat: EXP_CATS[0], notes: '', ...(rec || {}) }));
  const set = (k, v) => setF(p => ({ ...p, [k]: v }));
  return (
    <Box title={rec ? 'עריכת ספק' : 'ספק חדש'} onClose={onClose}
         footer={<><button className="mg-btn" disabled={!String(f.name).trim()} onClick={() => onSave({ ...f, name: String(f.name).trim(), review: false })}>שמור</button>
                   <button className="mg-btn ghost" onClick={onClose}>ביטול</button></>}>
      <div style={grid}>
        <Field label="שם"><input value={f.name} onChange={e => set('name', e.target.value)} /></Field>
        <Field label="ח.פ. / ע.מ."><input dir="ltr" value={f.taxId} onChange={e => set('taxId', e.target.value)} /></Field>
        <Field label="טלפון"><input dir="ltr" value={f.phone} onChange={e => set('phone', e.target.value)} /></Field>
        <Field label="אימייל"><input dir="ltr" value={f.email} onChange={e => set('email', e.target.value)} /></Field>
        <Field label="קטגוריה קבועה"><select value={f.cat} onChange={e => set('cat', e.target.value)}>{EXP_CATS.map(c => <option key={c}>{c}</option>)}</select></Field>
        <Field label="הערות"><input value={f.notes || ''} onChange={e => set('notes', e.target.value)} /></Field>
      </div>
    </Box>
  );
}

/* --------------------------------------------------------------------- בנק */
function BankTab({ bank, income, outgo, onSave, onDel, onBulk, flash }) {
  const [show, setShow] = useState('open');
  const [add, setAdd] = useState(null);
  const [busy, setBusy] = useState(false);

  const taken = new Set(bank.map(b => b.matchId).filter(Boolean));
  /* Same amount, within a week. */
  const candidates = (b) => {
    const t = Date.parse(b.date);
    const near = (d) => Math.abs(Date.parse(d) - t) <= 7 * 86400000;
    const pool = b.amount > 0
      ? income.map(i => ({ id: i.id, label: `${heDate(i.date)} · ${i.desc}`, amt: i.gross, date: i.date }))
      : outgo.map(e => ({ id: 'e:' + e.id, label: `${heDate(e.date)} · ${e.desc}`, amt: e.gross, date: e.date }));
    return pool.filter(p => Math.abs(p.amt - Math.abs(b.amount)) < 1 && p.date && near(p.date)
                         && (!taken.has(p.id) || p.id === b.matchId));
  };
  const labelOf = (id) => {
    if (id.startsWith('e:')) { const e = outgo.find(x => 'e:' + x.id === id); return e ? `הוצאה · ${e.desc}` : 'הוצאה שנמחקה'; }
    const i = income.find(x => x.id === id); return i ? `הכנסה · ${i.desc}` : 'הכנסה שנמחקה';
  };

  const autoMatch = async () => {
    setBusy(true);
    const used = new Set(taken);
    const recs = [];
    bank.filter(b => !b.matchId && !b.ignored).forEach(b => {
      const c = candidates(b).filter(x => !used.has(x.id));
      if (c.length === 1) { used.add(c[0].id); recs.push({ ...b, matchId: c[0].id }); }
    });
    const n = recs.length ? await onBulk(recs) : 0;
    setBusy(false);
    flash(n ? `הותאמו ${n} שורות` : 'לא נמצאו התאמות חד-משמעיות. אפשר להתאים ידנית.');
  };

  const importFile = async (file) => {
    if (!file) return;
    const rows = parseBankCSV(await file.text());
    if (!rows.length) { flash('לא זוהו שורות בקובץ. צריך CSV עם תאריך, תיאור וסכום.'); return; }
    const have = new Set(bank.map(b => `${b.date}|${b.amount}|${b.desc}`));
    const batch = uid('imp');
    const fresh = rows.filter(r => !have.has(`${r.date}|${r.amount}|${r.desc}`))
      .map(r => ({ ...r, id: uid('bk'), batch, matchId: '', ignored: false }));
    setBusy(true);
    const n = fresh.length ? await onBulk(fresh) : 0;
    setBusy(false);
    flash(`יובאו ${n} שורות חדשות${rows.length - fresh.length ? ` · ${rows.length - fresh.length} כבר היו` : ''}`);
  };

  const list = [...bank].sort((a, b) => (b.date || '').localeCompare(a.date || ''))
    .filter(b => show === 'all' || (show === 'open' ? !b.matchId && !b.ignored : !!b.matchId));

  return (
    <>
      <div className="mg-stats" style={{ marginBottom: 14 }}>
        <div className="mg-stat"><div className="lb">שורות בנק</div><div className="vl">{bank.length}</div></div>
        <div className="mg-stat"><div className="lb">הותאמו</div><div className="vl">{bank.filter(b => b.matchId).length}</div></div>
        <div className="mg-stat"><div className="lb">פתוחות</div><div className="vl">{bank.filter(b => !b.matchId && !b.ignored).length}</div></div>
        <div className="mg-stat"><div className="lb">תנועה נטו</div><div className="vl">{fmt(bank.reduce((a, b) => a + (Number(b.amount) || 0), 0))}</div></div>
      </div>
      <div style={{ ...row, marginBottom: 12, alignItems: 'center' }}>
        <label className="mg-btn" style={{ cursor: 'pointer' }}>⬆ ייבוא דף בנק (CSV)
          <input type="file" accept=".csv,text/csv,.txt" hidden onChange={e => { importFile(e.target.files?.[0]); e.target.value = ''; }} /></label>
        <button className="mg-btn ghost" disabled={busy} onClick={autoMatch}>↻ התאמה אוטומטית</button>
        <button className="mg-btn ghost" onClick={() => setAdd({ id: uid('bk'), date: todayIso(), desc: '', amount: '', matchId: '' })}>＋ שורה ידנית</button>
        <select value={show} onChange={e => setShow(e.target.value)} style={{ width: 'auto' }}>
          <option value="open">פתוחות</option><option value="done">מותאמות</option><option value="all">הכול</option></select>
      </div>
      <div className="mg-note" style={{ marginBottom: 12 }}>
        מורידים מאתר הבנק את התנועות לאקסל, שומרים כ-CSV ומעלים כאן. ההתאמה מחפשת תנועה באותו סכום, עד שבוע מהתאריך.
      </div>
      <div className="mg-tblwrap"><table className="mg-tbl">
        <thead><tr><th>תאריך</th><th>תיאור בבנק</th><th>סכום</th><th>מותאם ל</th><th></th></tr></thead>
        <tbody>
          {list.map(b => {
            const c = candidates(b);
            return (
              <tr key={b.id} style={b.ignored ? { opacity: .5 } : undefined}>
                <td>{heDate(b.date)}</td><td>{b.desc}</td>
                <td style={{ color: b.amount > 0 ? 'var(--green2)' : 'var(--bad)', fontWeight: 700 }} dir="ltr">{fmt(b.amount)}</td>
                <td>{b.matchId ? <span className="mg-chip ok">{labelOf(b.matchId)}</span>
                  : b.ignored ? <span className="mg-chip">לא רלוונטי</span>
                  : c.length
                    ? <select value="" onChange={e => e.target.value && onSave({ ...b, matchId: e.target.value })}>
                        <option value="">{c.length} הצעות, בחר…</option>
                        {c.map(x => <option key={x.id} value={x.id}>{x.label}</option>)}</select>
                    : <span style={{ color: 'var(--warn)', fontSize: 13 }}>אין תנועה תואמת. הוסף הכנסה או הוצאה.</span>}</td>
                <td><div style={{ display: 'flex', gap: 4 }}>
                  {b.matchId && <button className="mg-btn ghost sm" onClick={() => onSave({ ...b, matchId: '' })}>בטל התאמה</button>}
                  {!b.matchId && <button className="mg-btn ghost sm" onClick={() => onSave({ ...b, ignored: !b.ignored })}>{b.ignored ? 'החזר' : 'התעלם'}</button>}
                  <button className="mg-btn ghost sm" onClick={() => onDel(b)}>🗑</button></div></td>
              </tr>
            );
          })}
          {!list.length && <tr><td colSpan={5}><div className="mg-empty">{show === 'open' ? 'אין שורות פתוחות.' : 'אין שורות.'}</div></td></tr>}
        </tbody>
      </table></div>

      {add && (
        <Box title="שורת בנק" onClose={() => setAdd(null)}
             footer={<><button className="mg-btn" disabled={!add.date || !num(add.amount)}
                               onClick={async () => { if (await onSave({ ...add, amount: r2(num(add.amount)) })) setAdd(null); }}>שמור</button>
                       <button className="mg-btn ghost" onClick={() => setAdd(null)}>ביטול</button></>}>
          <div style={grid}>
            <Field label="תאריך"><input type="date" value={add.date} onChange={e => setAdd(a => ({ ...a, date: e.target.value }))} /></Field>
            <Field label="תיאור"><input value={add.desc} onChange={e => setAdd(a => ({ ...a, desc: e.target.value }))} /></Field>
            <Field label="סכום (זיכוי חיובי, חיוב במינוס)"><input dir="ltr" value={add.amount} onChange={e => setAdd(a => ({ ...a, amount: e.target.value }))} /></Field>
          </div>
        </Box>
      )}
    </>
  );
}

/* -------------------------------------------------------------------- מע״מ */
function VatTab({ totals, rate, book }) {
  const [mode, setMode] = useState('bi');
  const [month, setMonth] = useState(thisMonth());
  const start = mode === 'bi' ? biStart(month) : month;
  const end = mode === 'bi' ? addMonths(start, 1) : start;
  const t = totals(start, end);
  const label = start === end ? monthName(start) : `${monthName(start)}–${monthName(end)}`;

  if (rate === 0) return (
    <div className="mg-note">
      העסק מוגדר כ<b>עוסק פטור</b>, ולכן אין דיווח מע״מ תקופתי. מחזור השנה עד כה:{' '}
      <b>{fmt(totals(month.slice(0, 4) + '-01', month.slice(0, 4) + '-12').incGross)}</b>.
      עוסק פטור שעובר את תקרת המחזור השנתית צריך לעבור לעוסק מורשה.
    </div>
  );

  return (
    <>
      <div style={{ ...row, marginBottom: 14 }}>
        <Field label="תדירות דיווח"><select value={mode} onChange={e => setMode(e.target.value)}>
          <option value="bi">דו-חודשי</option><option value="month">חודשי</option></select></Field>
        <Field label="תקופה"><input type="month" value={month} onChange={e => e.target.value && setMonth(e.target.value)} /></Field>
        <button className="mg-btn ghost sm" onClick={() => downloadCSV(`vat-${book.name}-${start}${start !== end ? '_' + end : ''}.csv`, [
          ['דוח מע״מ', label], ['עוסק', book.legalName || book.name, book.taxId || ''], [],
          ['', 'בסיס (לפני מע״מ)', 'מע״מ'],
          ['עסקאות חייבות', r2(t.incNet), r2(t.incVat)],
          ['תשומות', r2(t.expNet), r2(t.expVat)],
          ['לתשלום / להחזר', '', r2(t.vatDue)], [],
          ['פירוט עסקאות'], ['תאריך', 'תיאור', 'מסמך', 'לפני מע״מ', 'מע״מ', 'סה״כ'],
          ...t.inc.map(i => [i.date, i.desc, i.docNo, r2(i.gross - i.vat), i.vat, i.gross]), [],
          ['פירוט תשומות'], ['תאריך', 'תיאור', 'מסמך', 'לפני מע״מ', 'מע״מ', 'סה״כ'],
          ...t.exp.map(e => [e.date, e.desc, e.docNo, r2(e.gross - e.vat), e.vat, e.gross]),
        ])}>⬇ דוח לרואה החשבון</button>
      </div>
      <div className="mg-stats" style={{ marginBottom: 16 }}>
        <div className="mg-stat"><div className="lb">עסקאות (לפני מע״מ)</div><div className="vl">{fmt(t.incNet)}</div><div className="dl">מע״מ עסקאות {fmt(t.incVat)}</div></div>
        <div className="mg-stat"><div className="lb">תשומות (לפני מע״מ)</div><div className="vl">{fmt(t.expNet)}</div><div className="dl">מע״מ תשומות {fmt(t.expVat)}</div></div>
        <div className="mg-stat"><div className="lb">{t.vatDue >= 0 ? 'לתשלום' : 'להחזר'} · {label}</div><div className="vl">{fmt(Math.abs(t.vatDue))}</div>
          <div className="dl">עד ה-15 בחודש שאחרי התקופה</div></div>
      </div>
      {t.inc.some(i => !i.docNo) && <div className="mg-note warn" style={{ marginBottom: 12 }}>
        {t.inc.filter(i => !i.docNo).length} הכנסות בתקופה בלי מסמך. המע״מ שלהן נספר, אבל כל אחת צריכה חשבונית.</div>}
      {t.exp.some(e => e.vat > 0 && !e.docNo && !e.hasDoc) && <div className="mg-note warn" style={{ marginBottom: 12 }}>
        יש תשומות בלי מספר חשבונית. בלי חשבונית מס מקורית אי אפשר לקזז אותן.</div>}
      <div className="mg-note">
        חישוב עזר לפי מה שרשום במערכת, לא דיווח רשמי. אם כמה עסקים רשומים תחת אותו ע.מ., הדיווח המאוחד נמצא בדף "כל העסקים".
      </div>
    </>
  );
}

/* ------------------------------------------------------------ רווח והפסד */
function PnlTab({ totals, supName, book }) {
  const y = new Date().getFullYear();
  const [from, setFrom] = useState(`${y}-01`);
  const [to, setTo] = useState(thisMonth());
  const t = totals(from, to);
  const group = (list, key) => {
    const g = {};
    list.forEach(x => { const k = key(x); g[k] = (g[k] || 0) + (x.gross - x.vat); });
    return Object.entries(g).sort((a, b) => b[1] - a[1]);
  };
  const incBy = group(t.inc, i => i.cat || 'אחר');
  const expBy = group(t.exp, e => e.cat || 'אחר');
  const supBy = group(t.exp.filter(e => e.supplierId || e.supplierName), e => supName(e.supplierId) || e.supplierName).slice(0, 8);
  const margin = t.incNet ? Math.round(t.profit / t.incNet * 100) : 0;
  const Line = ({ l, v, strong, color }) => (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #f0ebe0', fontWeight: strong ? 800 : 400, color }}>
      <span>{l}</span><span dir="ltr">{fmt(v)}</span></div>
  );
  return (
    <>
      <div style={{ ...row, marginBottom: 14 }}>
        <Field label="מחודש"><input type="month" value={from} onChange={e => e.target.value && setFrom(e.target.value)} /></Field>
        <Field label="עד חודש"><input type="month" value={to} onChange={e => e.target.value && setTo(e.target.value)} /></Field>
        <button className="mg-btn ghost sm" onClick={() => downloadCSV(`pnl-${book.name}-${from}_${to}.csv`, [
          ['דוח רווח והפסד', book.legalName || book.name, `${from} עד ${to}`], [],
          ['הכנסות לפי קטגוריה'], ...incBy.map(([k, v]) => [k, r2(v)]), ['סה״כ הכנסות', r2(t.incNet)], [],
          ['הוצאות לפי קטגוריה'], ...expBy.map(([k, v]) => [k, r2(v)]), ['סה״כ הוצאות', r2(t.expNet)], [],
          ['רווח', r2(t.profit)]
        ])}>⬇ ייצוא</button>
        <button className="mg-btn ghost sm" onClick={() => downloadCSV(`ledger-${book.name}-${from}_${to}.csv`, [
          ['סוג', 'תאריך', 'תיאור', 'קטגוריה', 'ספק / מקור', 'מסמך', 'אמצעי תשלום', 'לפני מע״מ', 'מע״מ', 'סה״כ'],
          ...t.inc.map(i => ['הכנסה', i.date, i.desc, i.cat, i.src === 'shop' ? 'חנות' : 'ידני', i.docNo, i.pay, r2(i.gross - i.vat), i.vat, i.gross]),
          ...t.exp.map(e => ['הוצאה', e.date, e.desc, e.cat, supName(e.supplierId) || e.supplierName || '', e.docNo, e.pay, r2(e.gross - e.vat), e.vat, e.gross]),
        ])}>⬇ כל התנועות לרואה החשבון</button>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))', gap: 16 }}>
        <div className="mg-card">
          <h3 style={{ marginTop: 0 }}>תמצית · {monthName(from)} עד {monthName(to)}</h3>
          <Line l="הכנסות (לפני מע״מ)" v={t.incNet} color="var(--green2)" />
          <Line l="הוצאות (לפני מע״מ)" v={-t.expNet} color="#b8641c" />
          <Line l="רווח" v={t.profit} strong color={t.profit < 0 ? 'var(--bad)' : 'var(--green)'} />
          <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 8 }}>שיעור רווח: {margin}%</div>
        </div>
        <div className="mg-card">
          <h3 style={{ marginTop: 0 }}>הכנסות לפי קטגוריה</h3>
          {incBy.map(([k, v]) => <Line key={k} l={k} v={v} />)}
          {!incBy.length && <div className="mg-empty">אין הכנסות בטווח.</div>}
        </div>
        <div className="mg-card">
          <h3 style={{ marginTop: 0 }}>הוצאות לפי קטגוריה</h3>
          {expBy.map(([k, v]) => (
            <div key={k} style={{ padding: '6px 0' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14 }}><span>{k}</span><span dir="ltr">{fmt(v)}</span></div>
              <div style={{ height: 6, background: '#f0ebe0', borderRadius: 4, marginTop: 4 }}>
                <div style={{ width: `${t.expNet ? v / t.expNet * 100 : 0}%`, height: '100%', background: '#d9822b', borderRadius: 4 }} /></div>
            </div>
          ))}
          {!expBy.length && <div className="mg-empty">אין הוצאות בטווח.</div>}
        </div>
        {supBy.length > 0 && <div className="mg-card">
          <h3 style={{ marginTop: 0 }}>ספקים מובילים</h3>
          {supBy.map(([k, v]) => <Line key={k} l={k} v={v} />)}
        </div>}
      </div>
    </>
  );
}

/* ------------------------------------------------------------------- ייבוא */
/* The old ERP (tizon-event) kept everything in one Realtime Database node.
   Copied into this book under ids built from the old ones, so a second run
   skips what is already here. Its amounts never separated VAT. */
function ImportTab({ data, cols, flash, onDone, onDeleteBook }) {
  const [old, setOld] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [pick, setPick] = useState({ incomes: true, expenses: true, suppliers: true });

  const fetchOld = async () => {
    setBusy(true); setErr('');
    try {
      const res = await fetch(OLD_ERP_URL);
      if (!res.ok) throw new Error(res.status === 401 ? 'המערכת הישנה דורשת הרשאה' : 'שגיאה ' + res.status);
      const d = await res.json();
      if (!d) throw new Error('המערכת הישנה ריקה');
      const arr = (x) => Array.isArray(x) ? x.filter(Boolean) : x && typeof x === 'object' ? Object.values(x) : [];
      setOld({ incomes: arr(d.incomes), expenses: arr(d.expenses), suppliers: arr(d.suppliers), customers: arr(d.customers) });
    } catch (e) { setErr(String(e.message || e)); }
    setBusy(false);
  };

  const run = async () => {
    setBusy(true);
    const have = new Set([...(data.incomes || []), ...(data.expenses || []), ...(data.suppliers || [])].map(x => x.id));
    const put = async (col, rec) => { try { await withTimeout(col.put(rec.id, clean(rec)), 12000); return 1; } catch { return 0; } };
    let n = 0, skipped = 0;
    if (pick.suppliers) for (const s of old.suppliers) {
      const id = 'erp_sup_' + s.id;
      if (have.has(id)) { skipped++; continue; }
      n += await put(cols.suppliers, { id, name: s.name || '', phone: s.phone || '', email: s.email || '', taxId: '',
                                       cat: 'אחר', notes: s.service || '', review: true, src: 'erp' });
    }
    if (pick.incomes) for (const i of old.incomes) {
      const id = 'erp_inc_' + i.id;
      if (have.has(id)) { skipped++; continue; }
      n += await put(cols.incomes, { id, src: 'erp', date: d10(i.date), desc: i.desc || 'הכנסה מהמערכת הישנה',
                                     cat: 'אחר', pay: i.status || '', gross: r2(i.totalAmount), docNo: '', review: true });
    }
    if (pick.expenses) for (const e of old.expenses) {
      const id = 'erp_exp_' + e.id;
      if (have.has(id)) { skipped++; continue; }
      n += await put(cols.expenses, { id, src: 'erp', date: d10(e.date), desc: e.desc || 'הוצאה מהמערכת הישנה',
                                      cat: EXP_CATS.includes(e.cat) ? e.cat : 'אחר',
                                      ...(e.cat && !EXP_CATS.includes(e.cat) ? { oldCat: e.cat } : {}),
                                      pay: '', gross: r2(e.totalAmount), vat: 0, vatMode: 'none', docNo: '', hasDoc: false, review: true });
    }
    setBusy(false);
    flash(`יובאו ${n} רשומות${skipped ? ` · ${skipped} כבר היו` : ''}`);
    onDone();
  };

  return (
    <>
      <div className="mg-card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginTop: 0 }}>ייבוא מה-ERP הישן</h3>
        <p style={{ marginTop: 0 }}>מעתיק לעסק הזה את ההכנסות, ההוצאות והספקים מהמערכת הקודמת (tizon-event). המערכת הישנה לא נפגעת, והרצה חוזרת לא מכפילה.</p>
        {!old && <button className="mg-btn" disabled={busy} onClick={fetchOld}>{busy ? 'קורא…' : 'קרא את המערכת הישנה'}</button>}
        {err && <div className="mg-note bad" style={{ marginTop: 10 }}>לא הצלחתי לקרוא: {err}</div>}
        {old && <>
          <div className="mg-stats" style={{ margin: '12px 0' }}>
            <div className="mg-stat"><div className="lb">הכנסות</div><div className="vl">{old.incomes.length}</div>
              <div className="dl">{fmt(old.incomes.reduce((a, i) => a + (Number(i.totalAmount) || 0), 0))}</div></div>
            <div className="mg-stat"><div className="lb">הוצאות</div><div className="vl">{old.expenses.length}</div>
              <div className="dl">{fmt(old.expenses.reduce((a, i) => a + (Number(i.totalAmount) || 0), 0))}</div></div>
            <div className="mg-stat"><div className="lb">ספקים</div><div className="vl">{old.suppliers.length}</div></div>
            <div className="mg-stat"><div className="lb">לקוחות</div><div className="vl">{old.customers.length}</div><div className="dl">לא מיובאים</div></div>
          </div>
          <div style={{ display: 'flex', gap: 16, marginBottom: 12 }}>
            {[['incomes', 'הכנסות'], ['expenses', 'הוצאות'], ['suppliers', 'ספקים']].map(([k, l]) => (
              <label key={k} style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                <input type="checkbox" style={{ width: 'auto' }} checked={pick[k]} onChange={e => setPick(p => ({ ...p, [k]: e.target.checked }))} />{l}</label>
            ))}
          </div>
          <div className="mg-note warn" style={{ marginBottom: 12 }}>
            במערכת הישנה הסכומים נשמרו בלי פירוק מע״מ. ההוצאות ייכנסו בלי מע״מ לקיזוז ויסומנו "לבדיקה". פותחים כל אחת ומעדכנים.
            אם חלק מההכנסות הישנות הן מכירות שכבר נמשכות מהחנות, מוחקים אותן כדי שלא ייספרו פעמיים.
          </div>
          <button className="mg-btn" disabled={busy} onClick={run}>{busy ? 'מייבא…' : 'ייבא לעסק הזה'}</button>
        </>}
      </div>
      <div className="mg-card" style={{ borderColor: '#f0c9c5' }}>
        <h3 style={{ marginTop: 0, color: 'var(--bad)' }}>מחיקת העסק</h3>
        <p style={{ marginTop: 0 }}>מוחק את הספר ואת כל ההכנסות, ההוצאות, הספקים ושורות הבנק שלו. ההזמנות בחנות לא נפגעות.</p>
        <button className="mg-btn danger" onClick={onDeleteBook}>מחק את העסק</button>
      </div>
    </>
  );
}

/* ================================================================== mount */
const style = document.createElement('style');
style.textContent = CSS;
document.head.appendChild(style);
const fonts = document.createElement('link');
fonts.rel = 'stylesheet';
fonts.href = 'https://fonts.googleapis.com/css2?family=Assistant:wght@400;600;700;800&family=Frank+Ruhl+Libre:wght@500;700&display=swap';
document.head.appendChild(fonts);
createRoot(document.getElementById('root')).render(<App />);
